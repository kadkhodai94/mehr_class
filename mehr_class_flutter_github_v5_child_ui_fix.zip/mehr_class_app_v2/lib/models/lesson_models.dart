enum GradeLevel { gradeOne, gradeTwo }
enum LessonType { letters, numbers, writing, story, lifeSkill, math }

class AudioModel {
  final String id;
  final String title;
  final String localAssetPath;
  final String? remoteUrl;
  final bool requiredOffline;

  const AudioModel({
    required this.id,
    required this.title,
    required this.localAssetPath,
    this.remoteUrl,
    this.requiredOffline = true,
  });

  factory AudioModel.fromJson(Map<String, dynamic> json) => AudioModel(
        id: json['id'] as String,
        title: json['title'] as String,
        localAssetPath: json['localAssetPath'] as String? ?? '',
        remoteUrl: json['remoteUrl'] as String?,
        requiredOffline: json['requiredOffline'] as bool? ?? false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'localAssetPath': localAssetPath,
        'remoteUrl': remoteUrl,
        'requiredOffline': requiredOffline,
      };
}

class LessonModel {
  final String id;
  final String title;
  final String subtitle;
  final String display;
  final GradeLevel grade;
  final LessonType type;
  final String iconLabel;
  final AudioModel? audio;
  final List<String> examples;
  final bool locked;

  const LessonModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.display,
    required this.grade,
    required this.type,
    required this.iconLabel,
    this.audio,
    this.examples = const [],
    this.locked = false,
  });
}

class ProgressModel {
  final int stars;
  final Set<String> completedLessonIds;
  final DateTime? lastSyncAt;

  const ProgressModel({
    required this.stars,
    required this.completedLessonIds,
    this.lastSyncAt,
  });

  factory ProgressModel.empty() => const ProgressModel(stars: 0, completedLessonIds: <String>{});

  ProgressModel copyWith({int? stars, Set<String>? completedLessonIds, DateTime? lastSyncAt}) => ProgressModel(
        stars: stars ?? this.stars,
        completedLessonIds: completedLessonIds ?? this.completedLessonIds,
        lastSyncAt: lastSyncAt ?? this.lastSyncAt,
      );
}

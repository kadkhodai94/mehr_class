import 'dart:async';

class SyncResult {
  final bool success;
  final String message;

  const SyncResult({required this.success, required this.message});
}

class SyncService {
  const SyncService();

  /// Backend is intentionally disabled in this version.
  /// Later, the admin panel can return lessons, audio URLs, content versions,
  /// and downloadable offline packs. The app UI already expects this flow.
  Future<SyncResult> checkForContentUpdates() async {
    await Future<void>.delayed(const Duration(milliseconds: 450));
    return const SyncResult(
      success: false,
      message: 'نسخه فعلی آفلاین است. اتصال به پنل در نسخه بعد فعال می‌شود.',
    );
  }
}

import 'package:shared_preferences/shared_preferences.dart';
import '../models/lesson_models.dart';

class ProgressStore {
  static const _starsKey = 'progress_stars';
  static const _completedKey = 'progress_completed_lessons';
  static const _lastSyncKey = 'progress_last_sync_at';

  static Future<ProgressModel> load() async {
    final prefs = await SharedPreferences.getInstance();
    final ids = prefs.getStringList(_completedKey) ?? <String>[];
    final sync = prefs.getString(_lastSyncKey);
    return ProgressModel(
      stars: prefs.getInt(_starsKey) ?? 0,
      completedLessonIds: ids.toSet(),
      lastSyncAt: sync == null ? null : DateTime.tryParse(sync),
    );
  }

  static Future<ProgressModel> completeLesson(String lessonId) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await load();
    final completed = {...current.completedLessonIds};
    final isNew = completed.add(lessonId);
    final stars = current.stars + (isNew ? 1 : 0);
    await prefs.setStringList(_completedKey, completed.toList());
    await prefs.setInt(_starsKey, stars);
    return current.copyWith(stars: stars, completedLessonIds: completed);
  }

  static Future<void> saveLastSyncNow() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastSyncKey, DateTime.now().toIso8601String());
  }
}

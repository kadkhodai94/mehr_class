import 'package:audioplayers/audioplayers.dart';

class AppAudio {
  static final AudioPlayer _player = AudioPlayer();

  static Future<void> playAsset(String assetPath) async {
    try {
      await _player.stop();
      await _player.play(AssetSource(assetPath.replaceFirst('assets/', '')));
    } catch (_) {
      // Missing voice files must never break offline lessons.
    }
  }
}

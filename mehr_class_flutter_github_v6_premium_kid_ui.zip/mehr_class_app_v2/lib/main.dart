import 'package:flutter/material.dart';

import 'data/offline_content.dart';
import 'models/lesson_models.dart';
import 'services/app_audio.dart';
import 'services/progress_store.dart';
import 'services/sync_service.dart';
import 'widgets/app_widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MehrClassApp());
}

class MehrClassApp extends StatelessWidget {
  const MehrClassApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کلاس مهر',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        scaffoldBackgroundColor: KidColors.pageBottom,
        colorScheme: ColorScheme.fromSeed(seedColor: KidColors.blue),
        textTheme: Theme.of(context).textTheme.apply(
              bodyColor: KidColors.ink,
              displayColor: KidColors.ink,
              fontFamily: 'sans',
            ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: KidColors.blue,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: KidColors.deepBlue,
            side: BorderSide(color: KidColors.blue.withOpacity(.24), width: 1.5),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  ProgressModel progress = ProgressModel.empty();
  bool syncing = false;
  int tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _sync() async {
    setState(() => syncing = true);
    final result = await const SyncService().checkForContentUpdates();
    if (!mounted) return;
    setState(() => syncing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(result.message, textDirection: TextDirection.rtl),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: KidScaffold(
        bottomNavigationBar: _KidBottomNav(
          selectedIndex: tabIndex,
          onChanged: (value) => setState(() => tabIndex = value),
        ),
        child: IndexedStack(
          index: tabIndex,
          children: [
            _HomeTab(progress: progress, syncing: syncing, onSync: _sync, onChanged: _load),
            _AllLessonsTab(onChanged: _load),
            _RewardsTab(progress: progress),
            _ProfileTab(progress: progress),
            _AboutMeTab(progress: progress),
          ],
        ),
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  final ProgressModel progress;
  final bool syncing;
  final VoidCallback onSync;
  final VoidCallback onChanged;

  const _HomeTab({required this.progress, required this.syncing, required this.onSync, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
      children: [
        _AppHeader(stars: progress.stars),
        const SizedBox(height: 18),
        _PremiumHero(onPlay: () => AppAudio.playAsset(OfflineContent.commonWelcome.localAssetPath)),
        const SizedBox(height: 16),
        _SyncStatusCard(syncing: syncing, onSync: onSync),
        const SizedBox(height: 24),
        const SectionTitle('انتخاب پایه', emoji: '🌟'),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _GradeFancyCard(
                title: 'پایه اول',
                subtitle: 'شروع یادگیری با حروف و عددها',
                icon: Icons.park_rounded,
                colors: const [Color(0xFFDFF8C8), Color(0xFFB6F0A9)],
                accent: const Color(0xFF1A8B43),
                badge: const Color(0xFFE8FFDE),
                grade: GradeLevel.gradeOne,
                onChanged: onChanged,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _GradeFancyCard(
                title: 'پایه دوم',
                subtitle: 'جمع، قصه و تمرین‌های بیشتر',
                icon: Icons.rocket_launch_rounded,
                colors: const [Color(0xFFDDF3FF), Color(0xFFB7E6FF)],
                accent: KidColors.deepBlue,
                badge: const Color(0xFFE5F7FF),
                grade: GradeLevel.gradeTwo,
                onChanged: onChanged,
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle('بخش‌های آموزشی', emoji: '🎨'),
        const SizedBox(height: 12),
        _CategorySection(onChanged: onChanged),
        const SizedBox(height: 24),
        _HomeProgressBoard(progress: progress),
      ],
    );
  }
}

class _AppHeader extends StatelessWidget {
  final int stars;
  const _AppHeader({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF15B8FF), Color(0xFF295BFF)]),
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [
                    BoxShadow(blurRadius: 26, offset: const Offset(0, 14), color: KidColors.blue.withOpacity(.24)),
                  ],
                ),
                child: const Icon(Icons.auto_stories_rounded, color: Colors.white, size: 40),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('کلاس مهر', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: KidColors.ink)),
                    SizedBox(height: 4),
                    Text('آموزش کودکانه، آفلاین و آماده اتصال به پنل', style: TextStyle(fontSize: 13.3, fontWeight: FontWeight.w700, color: KidColors.muted, height: 1.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFFF7CE), Color(0xFFFFE58F)]),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white, width: 1.4),
            boxShadow: [BoxShadow(blurRadius: 16, offset: const Offset(0, 10), color: KidColors.yellow.withOpacity(.22))],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('$stars', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: KidColors.ink)),
              const SizedBox(width: 8),
              const Icon(Icons.star_rounded, color: Color(0xFFFFB300), size: 28),
            ],
          ),
        ),
      ],
    );
  }
}

class _PremiumHero extends StatelessWidget {
  final VoidCallback onPlay;
  const _PremiumHero({required this.onPlay});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      radius: 34,
      strongShadow: true,
      padding: const EdgeInsets.all(0),
      gradient: const [Color(0xFF0E8EFF), Color(0xFF35C8FF)],
      child: ClipRRect(
        borderRadius: BorderRadius.circular(34),
        child: Stack(
          children: [
            Positioned(
              left: -20,
              top: 18,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(color: Colors.white.withOpacity(.10), shape: BoxShape.circle),
              ),
            ),
            Positioned(
              right: -28,
              top: -18,
              child: Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(color: Colors.white.withOpacity(.10), shape: BoxShape.circle),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(.18),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text('🎈', style: TextStyle(fontSize: 16)),
                                  SizedBox(width: 6),
                                  Flexible(
                                    child: Text('یادگیری با بازی و صدا', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.5)),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),
                            const Text('سلام قهرمان کوچولو!', textAlign: TextAlign.right, style: TextStyle(color: Colors.white, fontSize: 29, fontWeight: FontWeight.w900, height: 1.25)),
                            const SizedBox(height: 10),
                            const Text(
                              'اینجا با صدا، تصویر و بازی،\nحروف فارسی، عددها، قصه‌ها و\nمهارت‌های زندگی را یاد می‌گیریم.',
                              textAlign: TextAlign.right,
                              style: TextStyle(color: Colors.white, fontSize: 15.2, fontWeight: FontWeight.w800, height: 1.8),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 118,
                        height: 132,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(.14),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: Colors.white.withOpacity(.55), width: 1.2),
                        ),
                        child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('🦁', style: TextStyle(fontSize: 70)),
                            SizedBox(height: 6),
                            Text('دوستِ یادگیری', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.14),
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: Colors.white.withOpacity(.28)),
                          ),
                          child: const Text(
                            'ویس‌های تو بعداً به‌جای این نمونه‌ها قرار می‌گیرند.',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.right,
                            style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w800, height: 1.6),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      ElevatedButton.icon(
                        onPressed: onPlay,
                        icon: const Icon(Icons.volume_up_rounded),
                        label: const Text('پخش ویس'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: KidColors.deepBlue,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: const [
                      _HeroMiniChip(icon: Icons.abc_rounded, label: 'حروف'),
                      SizedBox(width: 8),
                      _HeroMiniChip(icon: Icons.calculate_rounded, label: 'اعداد'),
                      SizedBox(width: 8),
                      _HeroMiniChip(icon: Icons.menu_book_rounded, label: 'قصه'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroMiniChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _HeroMiniChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.15),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withOpacity(.24)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12.5)),
          ],
        ),
      ),
    );
  }
}

class _SyncStatusCard extends StatelessWidget {
  final bool syncing;
  final VoidCallback onSync;
  const _SyncStatusCard({required this.syncing, required this.onSync});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      color: Colors.white,
      radius: 30,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          const IconBubble(icon: Icons.cloud_done_rounded, color: KidColors.green, size: 60, iconSize: 30, backgroundColor: Color(0xFFEFFFEF)),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('نسخه فعلی آفلاین کار می‌کند', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16.5, color: KidColors.ink)),
                SizedBox(height: 6),
                Text('ساختار sync برای پنل و دانلود محتوای آینده از همین حالا آماده شده است.', style: TextStyle(fontWeight: FontWeight.w700, height: 1.65, color: KidColors.muted, fontSize: 13.2)),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            children: [
              const IconBubble(emoji: '🍏', color: KidColors.green, size: 54, iconSize: 28, backgroundColor: Color(0xFFF4FFF4)),
              const SizedBox(height: 4),
              TextButton(
                onPressed: syncing ? null : onSync,
                style: TextButton.styleFrom(minimumSize: Size.zero, padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                child: Text(syncing ? 'درحال بررسی...' : 'بررسی', style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _GradeFancyCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final Color accent;
  final Color badge;
  final GradeLevel grade;
  final VoidCallback onChanged;

  const _GradeFancyCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
    required this.accent,
    required this.badge,
    required this.grade,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final lessons = OfflineContent.lessons.where((e) => e.grade == grade).toList();
    return KidCard(
      minHeight: 198,
      radius: 30,
      padding: const EdgeInsets.all(16),
      gradient: colors,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => LessonCollectionPage(title: title, subtitle: subtitle, lessons: lessons, onChanged: onChanged),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: badge,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white, width: 1.2),
                ),
                child: Icon(icon, color: accent, size: 30),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.65), borderRadius: BorderRadius.circular(999)),
                child: Text('${lessons.length} درس', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 12.5)),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Text(title, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 24, color: accent)),
          const SizedBox(height: 6),
          Text(subtitle, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: accent.withOpacity(.82), height: 1.55)),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(color: Colors.white.withOpacity(.52), borderRadius: BorderRadius.circular(18)),
            child: Row(
              children: [
                Icon(Icons.arrow_back_rounded, color: accent, size: 20),
                const SizedBox(width: 6),
                Text('ورود به درس‌ها', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CategorySection extends StatelessWidget {
  final VoidCallback onChanged;
  const _CategorySection({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = <_CategoryItem>[
      _CategoryItem('حروف فارسی', 'الفبا، صداها و کلمه‌ها', Icons.abc_rounded, KidColors.purple, const [Color(0xFFF6EAFF), Color(0xFFE7D8FF)], LessonType.letters),
      _CategoryItem('اعداد و ریاضی', 'شمارش و جمع‌های ساده', Icons.calculate_rounded, KidColors.orange, const [Color(0xFFFFF0E6), Color(0xFFFFD9C5)], LessonType.numbers),
      _CategoryItem('قصه و رنگ‌آمیزی', 'داستان‌های شیرین و رنگی', Icons.menu_book_rounded, const Color(0xFFE69A00), const [Color(0xFFFFF5D5), Color(0xFFFFE2A0)], LessonType.story),
      _CategoryItem('مهارت زندگی', 'نکته‌های مهم روزانه', Icons.favorite_rounded, KidColors.green, const [Color(0xFFE5FFE9), Color(0xFFC9F3D1)], LessonType.lifeSkill),
    ];

    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _CategoryCard(item: items[0], onChanged: onChanged)),
            const SizedBox(width: 12),
            Expanded(child: _CategoryCard(item: items[1], onChanged: onChanged)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _CategoryCard(item: items[2], onChanged: onChanged)),
            const SizedBox(width: 12),
            Expanded(child: _CategoryCard(item: items[3], onChanged: onChanged)),
          ],
        ),
      ],
    );
  }
}

class _CategoryItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final List<Color> colors;
  final LessonType type;

  _CategoryItem(this.title, this.subtitle, this.icon, this.accent, this.colors, this.type);
}

class _CategoryCard extends StatelessWidget {
  final _CategoryItem item;
  final VoidCallback onChanged;
  const _CategoryCard({required this.item, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final lessons = OfflineContent.lessons.where((e) => e.type == item.type || (item.type == LessonType.numbers && e.type == LessonType.math)).toList();
    return KidCard(
      minHeight: 194,
      radius: 30,
      padding: const EdgeInsets.all(15),
      gradient: item.colors,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => LessonCollectionPage(title: item.title, subtitle: item.subtitle, lessons: lessons, onChanged: onChanged),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.72),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white, width: 1.2),
                ),
                child: Icon(item.icon, color: item.accent, size: 28),
              ),
              const Spacer(),
              const Text('⭐', style: TextStyle(fontSize: 20)),
            ],
          ),
          const SizedBox(height: 16),
          Text(item.title, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18.5, color: item.accent, height: 1.35)),
          const SizedBox(height: 8),
          Text(item.subtitle, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: item.accent.withOpacity(.82), height: 1.6)),
          const Spacer(),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.64), borderRadius: BorderRadius.circular(999)),
                child: Text('${lessons.length} درس', style: TextStyle(color: item.accent, fontWeight: FontWeight.w900, fontSize: 12)),
              ),
              const Spacer(),
              Icon(Icons.arrow_back_rounded, color: item.accent),
            ],
          ),
        ],
      ),
    );
  }
}

class _HomeProgressBoard extends StatelessWidget {
  final ProgressModel progress;
  const _HomeProgressBoard({required this.progress});

  @override
  Widget build(BuildContext context) {
    final completed = progress.completedLessonIds.length;
    return KidCard(
      radius: 34,
      color: Colors.white,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('مسیر یادگیری', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 21, color: KidColors.ink))),
              SoftPill(
                color: KidColors.green,
                child: Text('$completed درس کامل شده', style: const TextStyle(color: KidColors.green, fontWeight: FontWeight.w900, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _StepTile(index: 1, title: 'گوش کن', subtitle: 'ویس درس را با دقت بشنو.', color: KidColors.blue, icon: Icons.headphones_rounded),
          const SizedBox(height: 10),
          _StepTile(index: 2, title: 'نگاه کن', subtitle: 'با تصویر و مثال بهتر یاد بگیر.', color: KidColors.purple, icon: Icons.visibility_rounded),
          const SizedBox(height: 10),
          _StepTile(index: 3, title: 'تمرین کن', subtitle: 'جواب بده و با انگشت تکرار کن.', color: KidColors.orange, icon: Icons.draw_rounded),
          const SizedBox(height: 10),
          _StepTile(index: 4, title: 'ستاره بگیر', subtitle: 'با هر درس یک قدم جلوتر برو.', color: KidColors.green, icon: Icons.star_rounded),
        ],
      ),
    );
  }
}

class _StepTile extends StatelessWidget {
  final int index;
  final String title;
  final String subtitle;
  final Color color;
  final IconData icon;
  const _StepTile({required this.index, required this.title, required this.subtitle, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(.06),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: color.withOpacity(.15), borderRadius: BorderRadius.circular(12)),
            child: Text('$index', style: TextStyle(color: color, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5, color: KidColors.ink)),
                const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5, color: KidColors.muted, height: 1.5)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          IconBubble(icon: icon, color: color, size: 50, iconSize: 24),
        ],
      ),
    );
  }
}

class LessonCollectionPage extends StatefulWidget {
  final String title;
  final String subtitle;
  final List<LessonModel> lessons;
  final VoidCallback onChanged;

  const LessonCollectionPage({super.key, required this.title, required this.subtitle, required this.lessons, required this.onChanged});

  @override
  State<LessonCollectionPage> createState() => _LessonCollectionPageState();
}

class _LessonCollectionPageState extends State<LessonCollectionPage> {
  ProgressModel progress = ProgressModel.empty();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _completeLesson(LessonModel lesson) async {
    progress = await ProgressStore.completeLesson(lesson.id);
    await AppAudio.playAsset('assets/audio/common/correct.mp3');
    widget.onChanged();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return PageShell(
      title: widget.title,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 26),
        children: [
          KidCard(
            radius: 28,
            gradient: const [Color(0xFFEAF7FF), Color(0xFFFFF7E8)],
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const IconBubble(icon: Icons.auto_awesome_rounded, color: KidColors.orange, size: 56, iconSize: 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18.5, color: KidColors.ink)),
                      const SizedBox(height: 4),
                      Text(widget.subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.5, fontSize: 13)),
                    ],
                  ),
                ),
                SoftPill(
                  color: KidColors.green,
                  child: Text('${widget.lessons.length} درس', style: const TextStyle(color: KidColors.green, fontWeight: FontWeight.w900, fontSize: 12)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          for (final lesson in widget.lessons) ...[
            _LessonPremiumCard(
              lesson: lesson,
              done: progress.completedLessonIds.contains(lesson.id),
              onPlay: lesson.audio == null ? null : () => AppAudio.playAsset(lesson.audio!.localAssetPath),
              onComplete: () => _completeLesson(lesson),
            ),
            const SizedBox(height: 14),
          ],
        ],
      ),
    );
  }
}

class _LessonPremiumCard extends StatelessWidget {
  final LessonModel lesson;
  final bool done;
  final VoidCallback? onPlay;
  final VoidCallback onComplete;

  const _LessonPremiumCard({required this.lesson, required this.done, required this.onPlay, required this.onComplete});

  _LessonStyle _style() {
    switch (lesson.type) {
      case LessonType.letters:
        return const _LessonStyle(KidColors.purple, [Color(0xFFF7EEFF), Color(0xFFEADFFF)], Icons.abc_rounded);
      case LessonType.numbers:
      case LessonType.math:
        return const _LessonStyle(KidColors.orange, [Color(0xFFFFF0E6), Color(0xFFFFDEC8)], Icons.calculate_rounded);
      case LessonType.story:
        return const _LessonStyle(Color(0xFFE69A00), [Color(0xFFFFF6D9), Color(0xFFFFE9AF)], Icons.menu_book_rounded);
      case LessonType.lifeSkill:
        return const _LessonStyle(KidColors.green, [Color(0xFFE7FFE9), Color(0xFFCFF4D6)], Icons.favorite_rounded);
      case LessonType.writing:
        return const _LessonStyle(KidColors.blue, [Color(0xFFE5F4FF), Color(0xFFCBE6FF)], Icons.draw_rounded);
    }
  }

  @override
  Widget build(BuildContext context) {
    final style = _style();
    return KidCard(
      radius: 30,
      padding: const EdgeInsets.all(16),
      gradient: style.colors,
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.74),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white, width: 1.2),
                ),
                child: Center(
                  child: lesson.display.length <= 3
                      ? Text(lesson.display, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: style.accent))
                      : Icon(style.icon, color: style.accent, size: 28),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: KidColors.ink))),
                        Icon(done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, color: done ? KidColors.green : KidColors.muted, size: 28),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(lesson.subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, fontSize: 13.4, height: 1.55)),
                    if (lesson.examples.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: lesson.examples
                            .map(
                              (e) => SoftPill(
                                color: style.accent,
                                child: Text(e, style: TextStyle(color: style.accent, fontWeight: FontWeight.w900, fontSize: 12.2)),
                              ),
                            )
                            .toList(),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onComplete,
                  icon: const Icon(Icons.star_rounded),
                  label: Text(done ? 'دوباره مرور کردم' : 'یاد گرفتم'),
                  style: ElevatedButton.styleFrom(backgroundColor: KidColors.blue, foregroundColor: Colors.white),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onPlay,
                  icon: const Icon(Icons.volume_up_rounded),
                  label: const Text('پخش ویس'),
                  style: OutlinedButton.styleFrom(side: BorderSide(color: style.accent.withOpacity(.28), width: 1.5), foregroundColor: style.accent),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _LessonStyle {
  final Color accent;
  final List<Color> colors;
  final IconData icon;
  const _LessonStyle(this.accent, this.colors, this.icon);
}

class _AllLessonsTab extends StatelessWidget {
  final VoidCallback onChanged;
  const _AllLessonsTab({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('همه درس‌ها', emoji: '📚'),
        const SizedBox(height: 12),
        KidCard(
          radius: 30,
          gradient: const [Color(0xFFEAF6FF), Color(0xFFFFF4E8)],
          child: const Text(
            'از اینجا می‌تونی سریع به بخش‌های مختلف آموزشی بروی و درس مورد علاقه‌ات را انتخاب کنی.',
            style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.7, fontSize: 13.2),
            textAlign: TextAlign.right,
          ),
        ),
        const SizedBox(height: 14),
        _CategorySection(onChanged: onChanged),
      ],
    );
  }
}

class _RewardsTab extends StatelessWidget {
  final ProgressModel progress;
  const _RewardsTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('جایزه‌ها', emoji: '🎁'),
        const SizedBox(height: 14),
        KidCard(
          radius: 32,
          gradient: const [Color(0xFFFFF2B8), Color(0xFFFFD971)],
          strongShadow: true,
          child: Column(
            children: [
              const Text('🏆', style: TextStyle(fontSize: 72)),
              const SizedBox(height: 8),
              const Text('قهرمان یادگیری', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: KidColors.ink)),
              const SizedBox(height: 8),
              Text('تا الان ${progress.stars} ستاره گرفتی و ${progress.completedLessonIds.length} درس را کامل کرده‌ای.', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, color: KidColors.ink, height: 1.7)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _RewardStat(title: 'ستاره‌ها', value: '${progress.stars}', color: KidColors.orange, emoji: '⭐')),
            const SizedBox(width: 12),
            Expanded(child: _RewardStat(title: 'درس کامل', value: '${progress.completedLessonIds.length}', color: KidColors.green, emoji: '✅')),
          ],
        ),
      ],
    );
  }
}

class _RewardStat extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  final String emoji;
  const _RewardStat({required this.title, required this.value, required this.color, required this.emoji});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      radius: 26,
      gradient: [Colors.white, color.withOpacity(.08)],
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 30)),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: color)),
          const SizedBox(height: 4),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: KidColors.muted)),
        ],
      ),
    );
  }
}

class _ProfileTab extends StatelessWidget {
  final ProgressModel progress;
  const _ProfileTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('پروفایل', emoji: '🎒'),
        const SizedBox(height: 14),
        KidCard(
          radius: 32,
          gradient: const [Color(0xFFF1F7FF), Color(0xFFFFF4E6)],
          child: Column(
            children: [
              Container(
                width: 86,
                height: 86,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30)),
                child: const Center(child: Text('🧒', style: TextStyle(fontSize: 50))),
              ),
              const SizedBox(height: 12),
              const Text('دانش‌آموز کلاس مهر', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: KidColors.ink)),
              const SizedBox(height: 6),
              const Text('یاد بگیر، بازی کن و ستاره جمع کن.', style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: _RewardStat(title: 'ستاره', value: '${progress.stars}', color: KidColors.orange, emoji: '⭐')),
                  const SizedBox(width: 12),
                  Expanded(child: _RewardStat(title: 'درس کامل', value: '${progress.completedLessonIds.length}', color: KidColors.green, emoji: '📘')),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AboutMeTab extends StatelessWidget {
  final ProgressModel progress;
  const _AboutMeTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('من', emoji: '🌈'),
        const SizedBox(height: 14),
        KidCard(
          radius: 32,
          gradient: const [Color(0xFFEAFDFF), Color(0xFFEFFFEF)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('سلام دوست کوچولو!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: KidColors.ink)),
              const SizedBox(height: 8),
              Text('تو الان ${progress.stars} ستاره داری. هر درس جدید یعنی یک قدم نزدیک‌تر به قهرمان شدن.', style: const TextStyle(fontWeight: FontWeight.w700, color: KidColors.muted, height: 1.8)),
              const SizedBox(height: 14),
              Row(
                children: const [
                  Expanded(child: _MiniInfoBox(emoji: '🎧', title: 'گوش کن')),
                  SizedBox(width: 10),
                  Expanded(child: _MiniInfoBox(emoji: '✍️', title: 'تمرین کن')),
                  SizedBox(width: 10),
                  Expanded(child: _MiniInfoBox(emoji: '⭐', title: 'جایزه بگیر')),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MiniInfoBox extends StatelessWidget {
  final String emoji;
  final String title;
  const _MiniInfoBox({required this.emoji, required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.85), borderRadius: BorderRadius.circular(20)),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 26)),
          const SizedBox(height: 6),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: KidColors.ink, fontSize: 12.5)),
        ],
      ),
    );
  }
}

class _KidBottomNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onChanged;

  const _KidBottomNav({required this.selectedIndex, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = [
      _NavItem('خانه', Icons.home_rounded, KidColors.blue),
      _NavItem('درس‌ها', Icons.grid_view_rounded, KidColors.deepBlue),
      _NavItem('جایزه‌ها', Icons.stars_rounded, KidColors.purple),
      _NavItem('پروفایل', Icons.backpack_rounded, KidColors.orange),
      _NavItem('من', Icons.face_rounded, KidColors.green),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      child: Container(
        height: 82,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.97),
          borderRadius: BorderRadius.circular(34),
          border: Border.all(color: Colors.white, width: 1.4),
          boxShadow: [BoxShadow(blurRadius: 30, offset: const Offset(0, 14), color: Colors.black.withOpacity(.12))],
        ),
        child: Row(
          children: [
            for (int i = 0; i < items.length; i++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onChanged(i),
                  child: _NavButton(item: items[i], selected: i == selectedIndex),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NavItem {
  final String label;
  final IconData icon;
  final Color color;
  const _NavItem(this.label, this.icon, this.color);
}

class _NavButton extends StatelessWidget {
  final _NavItem item;
  final bool selected;
  const _NavButton({required this.item, required this.selected});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(vertical: 7),
      decoration: BoxDecoration(
        color: selected ? item.color.withOpacity(.12) : Colors.transparent,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(item.icon, color: selected ? item.color : KidColors.muted, size: selected ? 28 : 24),
          const SizedBox(height: 3),
          Text(item.label, style: TextStyle(color: selected ? item.color : KidColors.muted, fontSize: 11, fontWeight: selected ? FontWeight.w900 : FontWeight.w700)),
        ],
      ),
    );
  }
}

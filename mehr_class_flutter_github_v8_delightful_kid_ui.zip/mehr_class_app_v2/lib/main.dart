import 'package:flutter/material.dart';

import 'data/offline_content.dart';
import 'models/lesson_models.dart';
import 'services/app_audio.dart';
import 'services/progress_store.dart';
import 'services/sync_service.dart';
import 'widgets/app_widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MehrClassApp());
}

class MehrClassApp extends StatelessWidget {
  const MehrClassApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کلاس مهر',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        scaffoldBackgroundColor: KidColors.pageBottom,
        colorScheme: ColorScheme.fromSeed(seedColor: KidColors.blue),
        textTheme: Theme.of(context).textTheme.apply(
              bodyColor: KidColors.ink,
              displayColor: KidColors.ink,
              fontFamily: 'sans',
            ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: KidColors.blue,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: KidColors.deepBlue,
            side: BorderSide(color: KidColors.blue.withOpacity(.24), width: 1.5),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  ProgressModel progress = ProgressModel.empty();
  bool syncing = false;
  int tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _sync() async {
    setState(() => syncing = true);
    final result = await const SyncService().checkForContentUpdates();
    if (!mounted) return;
    setState(() => syncing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(result.message, textDirection: TextDirection.rtl),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: KidScaffold(
        bottomNavigationBar: _KidBottomNav(selectedIndex: tabIndex, onChanged: (v) => setState(() => tabIndex = v)),
        child: IndexedStack(
          index: tabIndex,
          children: [
            _HomeTab(progress: progress, syncing: syncing, onSync: _sync, onChanged: _load),
            _ExploreTab(onChanged: _load),
            _RewardsTab(progress: progress),
            _BagTab(progress: progress),
            _FriendTab(progress: progress),
          ],
        ),
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  final ProgressModel progress;
  final bool syncing;
  final VoidCallback onSync;
  final VoidCallback onChanged;

  const _HomeTab({required this.progress, required this.syncing, required this.onSync, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
      children: [
        _Header(stars: progress.stars),
        const SizedBox(height: 16),
        _HeroWorldCard(onPlay: () => AppAudio.playAsset(OfflineContent.commonWelcome.localAssetPath)),
        const SizedBox(height: 16),
        _JoyRow(syncing: syncing, onSync: onSync, progress: progress),
        const SizedBox(height: 24),
        const SectionTitle('دو دنیای جادویی', emoji: '🌍'),
        const SizedBox(height: 12),
        _GradeWorlds(onChanged: onChanged),
        const SizedBox(height: 24),
        const SectionTitle('امروز کجا بازی کنیم؟', emoji: '🎠'),
        const SizedBox(height: 12),
        _AdventurePlaces(onChanged: onChanged),
        const SizedBox(height: 24),
        const SectionTitle('ماموریت امروز', emoji: '🎯'),
        const SizedBox(height: 12),
        _DailyMissionCard(progress: progress),
        const SizedBox(height: 24),
        const SectionTitle('راه ستاره‌ها', emoji: '⭐'),
        const SizedBox(height: 12),
        _PathBoard(progress: progress),
      ],
    );
  }
}

class _Header extends StatelessWidget {
  final int stars;
  const _Header({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF18C6FF), Color(0xFF2B6AFF)]),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(blurRadius: 24, offset: const Offset(0, 12), color: KidColors.blue.withOpacity(.23))],
                ),
                child: const Center(child: Text('🏫', style: TextStyle(fontSize: 40))),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('کلاس مهر', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: KidColors.ink)),
                    SizedBox(height: 4),
                    Text('شاد، بازی‌محور و مخصوص کلاس اولی‌ها و دومی‌ها', style: TextStyle(fontSize: 13, color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFFF7CC), Color(0xFFFFE17C)]),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white, width: 1.2),
            boxShadow: [BoxShadow(blurRadius: 14, offset: const Offset(0, 8), color: KidColors.yellow.withOpacity(.2))],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('$stars', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: KidColors.ink)),
              const SizedBox(width: 6),
              const Text('⭐', style: TextStyle(fontSize: 24)),
            ],
          ),
        ),
      ],
    );
  }
}

class _HeroWorldCard extends StatelessWidget {
  final VoidCallback onPlay;
  const _HeroWorldCard({required this.onPlay});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      radius: 38,
      strongShadow: true,
      padding: const EdgeInsets.all(0),
      gradient: const [Color(0xFF1096FF), Color(0xFF49D4FF)],
      child: ClipRRect(
        borderRadius: BorderRadius.circular(38),
        child: Stack(
          children: [
            Positioned(right: -30, top: -28, child: Container(width: 130, height: 130, decoration: BoxDecoration(color: Colors.white.withOpacity(.10), shape: BoxShape.circle))),
            Positioned(left: -20, bottom: -30, child: Container(width: 140, height: 140, decoration: BoxDecoration(color: Colors.white.withOpacity(.09), shape: BoxShape.circle))),
            Positioned(top: 18, left: 20, child: Text('☁️', style: TextStyle(fontSize: 34, color: Colors.white.withOpacity(.9)))),
            Positioned(top: 18, right: 20, child: const Text('🦋', style: TextStyle(fontSize: 24))),
            Positioned(top: 78, right: 72, child: const Text('🌈', style: TextStyle(fontSize: 42))),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(999)),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text('🎉', style: TextStyle(fontSize: 15)),
                                  SizedBox(width: 6),
                                  Flexible(child: Text('دوست کوچولوی من، خوش اومدی!', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.2))),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),
                            const Text('بزن بریم برای یادگیری!', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 30, height: 1.24)),
                            const SizedBox(height: 10),
                            const Text('با شیرِ دانا برو به باغ حروف، دنیای عددها، قصه‌خونه و شهر مهارت‌ها. اینجا یاد گرفتن مثل بازیه!', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, height: 1.8, fontSize: 14.7)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 128,
                        height: 150,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(.15),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: Colors.white.withOpacity(.6), width: 1.2),
                        ),
                        child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('🦁', style: TextStyle(fontSize: 78)),
                            SizedBox(height: 4),
                            Text('شیرِ دانا', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(color: Colors.white.withOpacity(.14), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withOpacity(.28))),
                          child: const Text('هرجا خواستی ویس‌ها را با صدای خودت جایگزین کن تا اپ برای بچه‌ها صمیمی‌تر بشه.', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.2, height: 1.7)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      ElevatedButton.icon(
                        onPressed: onPlay,
                        icon: const Icon(Icons.volume_up_rounded),
                        label: const Text('پخش ویس'),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: KidColors.deepBlue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999))),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  const Row(
                    children: [
                      Expanded(child: _MiniHeroChip(emoji: '🔤', label: 'حروف')),
                      SizedBox(width: 8),
                      Expanded(child: _MiniHeroChip(emoji: '🍎', label: 'عددها')),
                      SizedBox(width: 8),
                      Expanded(child: _MiniHeroChip(emoji: '📚', label: 'قصه‌ها')),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniHeroChip extends StatelessWidget {
  final String emoji;
  final String label;
  const _MiniHeroChip({required this.emoji, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.25))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12.2)),
        ],
      ),
    );
  }
}

class _JoyRow extends StatelessWidget {
  final bool syncing;
  final VoidCallback onSync;
  final ProgressModel progress;
  const _JoyRow({required this.syncing, required this.onSync, required this.progress});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: KidCard(
            radius: 28,
            color: Colors.white,
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                const IconBubble(emoji: '☁️', color: KidColors.green, size: 54, iconSize: 24, backgroundColor: Color(0xFFEFFFEF)),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text('بدون اینترنت هم کار می‌کنم', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13.2, color: KidColors.ink, height: 1.5)),
                ),
                TextButton(onPressed: syncing ? null : onSync, child: Text(syncing ? '...' : 'بررسی', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12))),
              ],
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: KidCard(
            radius: 28,
            gradient: const [Color(0xFFFFF5CB), Color(0xFFFFE395)],
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                const Text('🎁', style: TextStyle(fontSize: 28)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text('${progress.completedLessonIds.length} جایزه کوچک گرفتی', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13.1, color: KidColors.ink, height: 1.5)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _GradeWorlds extends StatelessWidget {
  final VoidCallback onChanged;
  const _GradeWorlds({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _WorldCard(
            title: 'سرزمین پایه اول',
            subtitle: 'شروع شیرین با حروف و عددها',
            emoji: '🌱',
            mascot: '🐣',
            colors: const [Color(0xFFE3FFCC), Color(0xFFC5F3A8)],
            accent: const Color(0xFF1A8B43),
            lessons: OfflineContent.lessons.where((e) => e.grade == GradeLevel.gradeOne).toList(),
            onChanged: onChanged,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _WorldCard(
            title: 'سرزمین پایه دوم',
            subtitle: 'تمرین‌های بیشتر و جذاب‌تر',
            emoji: '🚀',
            mascot: '🦊',
            colors: const [Color(0xFFDEF4FF), Color(0xFFC3E8FF)],
            accent: KidColors.deepBlue,
            lessons: OfflineContent.lessons.where((e) => e.grade == GradeLevel.gradeTwo).toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }
}

class _WorldCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String emoji;
  final String mascot;
  final List<Color> colors;
  final Color accent;
  final List<LessonModel> lessons;
  final VoidCallback onChanged;

  const _WorldCard({required this.title, required this.subtitle, required this.emoji, required this.mascot, required this.colors, required this.accent, required this.lessons, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      minHeight: 220,
      radius: 32,
      gradient: colors,
      padding: const EdgeInsets.all(16),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => LessonCollectionPage(title: title, subtitle: subtitle, lessons: lessons, onChanged: onChanged)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: Colors.white.withOpacity(.72), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white, width: 1.2)),
                child: Text(emoji, style: const TextStyle(fontSize: 30)),
              ),
              const Spacer(),
              Text(mascot, style: const TextStyle(fontSize: 28)),
            ],
          ),
          const SizedBox(height: 16),
          Text(title, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 21, color: accent, height: 1.35)),
          const SizedBox(height: 6),
          Text(subtitle, style: TextStyle(color: accent.withOpacity(.82), fontWeight: FontWeight.w700, fontSize: 13.1, height: 1.6)),
          const Spacer(),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.64), borderRadius: BorderRadius.circular(999)),
                child: Text('${lessons.length} درس', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 12)),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.54), borderRadius: BorderRadius.circular(18)),
                child: Row(
                  children: [
                    Icon(Icons.arrow_back_rounded, color: accent, size: 20),
                    const SizedBox(width: 4),
                    Text('ورود', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 12.5)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AdventurePlaces extends StatelessWidget {
  final VoidCallback onChanged;
  const _AdventurePlaces({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = <_PlaceItem>[
      _PlaceItem('باغ حروف', 'با گل‌های الفبا بازی کن', '🌳', '🐝', KidColors.purple, const [Color(0xFFF8EDFF), Color(0xFFE8D9FF)], LessonType.letters),
      _PlaceItem('دنیای عددها', 'سیب‌ها را بشمار', '🍎', '🐰', KidColors.orange, const [Color(0xFFFFF0E6), Color(0xFFFFDAC9)], LessonType.numbers),
      _PlaceItem('قصه‌خونه', 'داستان و خیال', '📚', '🦉', const Color(0xFFE09B00), const [Color(0xFFFFF8DA), Color(0xFFFFE8AD)], LessonType.story),
      _PlaceItem('شهر مهارت‌ها', 'کارهای خوب و قشنگ', '🧼', '🐼', KidColors.green, const [Color(0xFFE8FFE9), Color(0xFFD2F5D6)], LessonType.lifeSkill),
    ];
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _PlaceCard(item: items[0], onChanged: onChanged)),
            const SizedBox(width: 12),
            Expanded(child: _PlaceCard(item: items[1], onChanged: onChanged)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _PlaceCard(item: items[2], onChanged: onChanged)),
            const SizedBox(width: 12),
            Expanded(child: _PlaceCard(item: items[3], onChanged: onChanged)),
          ],
        ),
      ],
    );
  }
}

class _PlaceItem {
  final String title;
  final String subtitle;
  final String emoji;
  final String mascot;
  final Color accent;
  final List<Color> colors;
  final LessonType type;
  _PlaceItem(this.title, this.subtitle, this.emoji, this.mascot, this.accent, this.colors, this.type);
}

class _PlaceCard extends StatelessWidget {
  final _PlaceItem item;
  final VoidCallback onChanged;
  const _PlaceCard({required this.item, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final lessons = OfflineContent.lessons.where((e) => e.type == item.type || (item.type == LessonType.numbers && e.type == LessonType.math)).toList();
    return KidCard(
      minHeight: 220,
      radius: 32,
      gradient: item.colors,
      padding: const EdgeInsets.all(15),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonCollectionPage(title: item.title, subtitle: item.subtitle, lessons: lessons, onChanged: onChanged))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 62,
                height: 62,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: Colors.white.withOpacity(.72), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white, width: 1.2)),
                child: Text(item.emoji, style: const TextStyle(fontSize: 31)),
              ),
              const Spacer(),
              Text(item.mascot, style: const TextStyle(fontSize: 28)),
            ],
          ),
          const SizedBox(height: 16),
          Text(item.title, style: TextStyle(color: item.accent, fontSize: 19.5, fontWeight: FontWeight.w900, height: 1.3)),
          const SizedBox(height: 8),
          Text(item.subtitle, style: TextStyle(color: item.accent.withOpacity(.82), fontSize: 12.8, fontWeight: FontWeight.w700, height: 1.6)),
          const Spacer(),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.64), borderRadius: BorderRadius.circular(999)),
                child: Text('${lessons.length} مرحله', style: TextStyle(color: item.accent, fontWeight: FontWeight.w900, fontSize: 12)),
              ),
              const Spacer(),
              Icon(Icons.arrow_back_rounded, color: item.accent),
            ],
          ),
        ],
      ),
    );
  }
}

class _DailyMissionCard extends StatelessWidget {
  final ProgressModel progress;
  const _DailyMissionCard({required this.progress});

  @override
  Widget build(BuildContext context) {
    final completed = progress.completedLessonIds.length;
    final missionDone = completed >= 3;
    return KidCard(
      radius: 34,
      gradient: const [Color(0xFFFFEAF0), Color(0xFFFFD7E3)],
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 88,
            height: 88,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: Colors.white.withOpacity(.72), borderRadius: BorderRadius.circular(28)),
            child: Text(missionDone ? '🏅' : '🎯', style: const TextStyle(fontSize: 42)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(missionDone ? 'آفرین! ماموریت امروز انجام شد' : 'ماموریت امروز: ۳ درس یاد بگیر', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: KidColors.ink, height: 1.45)),
                const SizedBox(height: 6),
                Text(missionDone ? 'تو امروز عالی بودی و ماموریتت را کامل کردی.' : 'اگر امروز ۳ درس کامل کنی، یک حس خوب و کلی ستاره می‌گیری.', style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.7, fontSize: 13)),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    minHeight: 10,
                    value: (completed / 3).clamp(0.0, 1.0),
                    backgroundColor: Colors.white,
                    valueColor: const AlwaysStoppedAnimation<Color>(KidColors.coral),
                  ),
                ),
                const SizedBox(height: 8),
                Text('${completed.clamp(0, 3)}/3 مرحله', style: const TextStyle(fontWeight: FontWeight.w900, color: KidColors.coral, fontSize: 12.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PathBoard extends StatelessWidget {
  final ProgressModel progress;
  const _PathBoard({required this.progress});

  @override
  Widget build(BuildContext context) {
    final count = progress.completedLessonIds.length;
    return KidCard(
      radius: 34,
      color: Colors.white,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('راهِ قهرمان شدن', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 21, color: KidColors.ink))),
              SoftPill(color: KidColors.green, child: Text('$count درس کامل شده', style: const TextStyle(color: KidColors.green, fontWeight: FontWeight.w900, fontSize: 12))),
            ],
          ),
          const SizedBox(height: 16),
          const _PathStep(index: 1, emoji: '🎧', title: 'گوش کن', subtitle: 'صدای درس را بشنو.', color: KidColors.blue),
          const SizedBox(height: 10),
          const _PathStep(index: 2, emoji: '👀', title: 'نگاه کن', subtitle: 'به عکس‌ها و مثال‌ها دقت کن.', color: KidColors.purple),
          const SizedBox(height: 10),
          const _PathStep(index: 3, emoji: '✍️', title: 'تمرین کن', subtitle: 'جواب بده و تکرار کن.', color: KidColors.orange),
          const SizedBox(height: 10),
          const _PathStep(index: 4, emoji: '⭐', title: 'ستاره بگیر', subtitle: 'با هر درس، جلوتر برو.', color: KidColors.green),
        ],
      ),
    );
  }
}

class _PathStep extends StatelessWidget {
  final int index;
  final String emoji;
  final String title;
  final String subtitle;
  final Color color;
  const _PathStep({required this.index, required this.emoji, required this.title, required this.subtitle, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: color.withOpacity(.07), borderRadius: BorderRadius.circular(22)),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: color.withOpacity(.16), borderRadius: BorderRadius.circular(12)),
            child: Text('$index', style: TextStyle(color: color, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5, color: KidColors.ink)),
                const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, fontSize: 12.4, height: 1.55)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 52,
            height: 52,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(blurRadius: 12, offset: const Offset(0, 6), color: color.withOpacity(.16))]),
            child: Text(emoji, style: const TextStyle(fontSize: 24)),
          ),
        ],
      ),
    );
  }
}

class LessonCollectionPage extends StatefulWidget {
  final String title;
  final String subtitle;
  final List<LessonModel> lessons;
  final VoidCallback onChanged;

  const LessonCollectionPage({super.key, required this.title, required this.subtitle, required this.lessons, required this.onChanged});

  @override
  State<LessonCollectionPage> createState() => _LessonCollectionPageState();
}

class _LessonCollectionPageState extends State<LessonCollectionPage> {
  ProgressModel progress = ProgressModel.empty();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _completeLesson(LessonModel lesson) async {
    progress = await ProgressStore.completeLesson(lesson.id);
    await AppAudio.playAsset('assets/audio/common/correct.mp3');
    widget.onChanged();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return PageShell(
      title: widget.title,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        children: [
          KidCard(
            radius: 30,
            gradient: const [Color(0xFFEAF8FF), Color(0xFFFFF6E7)],
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 68,
                  height: 68,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
                  child: const Text('🎈', style: TextStyle(fontSize: 32)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19.2, color: KidColors.ink)),
                      const SizedBox(height: 4),
                      Text(widget.subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, fontSize: 13, height: 1.6)),
                    ],
                  ),
                ),
                SoftPill(color: KidColors.green, child: Text('${widget.lessons.length} مرحله', style: const TextStyle(color: KidColors.green, fontWeight: FontWeight.w900, fontSize: 12))),
              ],
            ),
          ),
          const SizedBox(height: 14),
          for (int i = 0; i < widget.lessons.length; i++) ...[
            _LessonStageCard(
              step: i + 1,
              lesson: widget.lessons[i],
              done: progress.completedLessonIds.contains(widget.lessons[i].id),
              onPlay: widget.lessons[i].audio == null ? null : () => AppAudio.playAsset(widget.lessons[i].audio!.localAssetPath),
              onComplete: () => _completeLesson(widget.lessons[i]),
            ),
            const SizedBox(height: 14),
          ],
        ],
      ),
    );
  }
}

class _LessonStageCard extends StatelessWidget {
  final int step;
  final LessonModel lesson;
  final bool done;
  final VoidCallback? onPlay;
  final VoidCallback onComplete;

  const _LessonStageCard({required this.step, required this.lesson, required this.done, required this.onPlay, required this.onComplete});

  _StageLook _look() {
    switch (lesson.type) {
      case LessonType.letters:
        return const _StageLook(KidColors.purple, [Color(0xFFF7EEFF), Color(0xFFEADBFF)], '🔤');
      case LessonType.numbers:
      case LessonType.math:
        return const _StageLook(KidColors.orange, [Color(0xFFFFF0E6), Color(0xFFFFDCC8)], '🍎');
      case LessonType.story:
        return const _StageLook(Color(0xFFE09B00), [Color(0xFFFFF7DA), Color(0xFFFFE7AE)], '📚');
      case LessonType.lifeSkill:
        return const _StageLook(KidColors.green, [Color(0xFFE8FFE9), Color(0xFFD1F4D6)], '🧼');
      case LessonType.writing:
        return const _StageLook(KidColors.blue, [Color(0xFFE6F4FF), Color(0xFFD1E8FF)], '✍️');
    }
  }

  @override
  Widget build(BuildContext context) {
    final look = _look();
    return KidCard(
      radius: 32,
      gradient: look.colors,
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 68,
                height: 68,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: Colors.white.withOpacity(.76), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white, width: 1.2)),
                child: lesson.display.length <= 3 ? Text(lesson.display, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: look.accent)) : Text(look.emoji, style: const TextStyle(fontSize: 30)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                          decoration: BoxDecoration(color: Colors.white.withOpacity(.6), borderRadius: BorderRadius.circular(999)),
                          child: Text('مرحله $step', style: TextStyle(color: look.accent, fontWeight: FontWeight.w900, fontSize: 11.5)),
                        ),
                        const Spacer(),
                        done ? const Text('✅', style: TextStyle(fontSize: 24)) : const Icon(Icons.radio_button_unchecked_rounded, color: KidColors.muted, size: 24),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19, color: KidColors.ink)),
                    const SizedBox(height: 4),
                    Text(lesson.subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, fontSize: 13.2, height: 1.6)),
                    if (lesson.examples.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: lesson.examples.map((e) => SoftPill(color: look.accent, child: Text(e, style: TextStyle(color: look.accent, fontWeight: FontWeight.w900, fontSize: 12)))).toList(),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onComplete,
                  icon: const Icon(Icons.star_rounded),
                  label: Text(done ? 'بلدم' : 'یاد گرفتم'),
                  style: ElevatedButton.styleFrom(backgroundColor: KidColors.blue, foregroundColor: Colors.white),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onPlay,
                  icon: const Icon(Icons.volume_up_rounded),
                  label: const Text('پخش ویس'),
                  style: OutlinedButton.styleFrom(foregroundColor: look.accent, side: BorderSide(color: look.accent.withOpacity(.3), width: 1.5)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StageLook {
  final Color accent;
  final List<Color> colors;
  final String emoji;
  const _StageLook(this.accent, this.colors, this.emoji);
}

class _ExploreTab extends StatelessWidget {
  final VoidCallback onChanged;
  const _ExploreTab({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('نقشه بازی', emoji: '🗺️'),
        const SizedBox(height: 12),
        KidCard(
          radius: 30,
          gradient: const [Color(0xFFEAF8FF), Color(0xFFFFF5E7)],
          child: const Text('از اینجا می‌تونی بین دنیاهای مختلف بچرخی و هرجایی که دوست داری بازی و یادگیری را شروع کنی.', style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.7, fontSize: 13.2), textAlign: TextAlign.right),
        ),
        const SizedBox(height: 14),
        _AdventurePlaces(onChanged: onChanged),
        const SizedBox(height: 14),
        _GradeWorlds(onChanged: onChanged),
      ],
    );
  }
}

class _RewardsTab extends StatelessWidget {
  final ProgressModel progress;
  const _RewardsTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('جایزه‌های من', emoji: '🎁'),
        const SizedBox(height: 14),
        KidCard(
          radius: 34,
          gradient: const [Color(0xFFFFF3B9), Color(0xFFFFD86D)],
          strongShadow: true,
          child: Column(
            children: [
              const Text('🏆', style: TextStyle(fontSize: 72)),
              const SizedBox(height: 8),
              const Text('آفرین قهرمان!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: KidColors.ink)),
              const SizedBox(height: 8),
              Text('تا الان ${progress.stars} ستاره گرفتی و ${progress.completedLessonIds.length} مرحله را کامل کردی.', textAlign: TextAlign.center, style: const TextStyle(color: KidColors.ink, fontWeight: FontWeight.w800, height: 1.75)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _RewardBox(title: 'ستاره‌ها', value: '${progress.stars}', emoji: '⭐', color: KidColors.orange)),
            const SizedBox(width: 12),
            Expanded(child: _RewardBox(title: 'مرحله کامل', value: '${progress.completedLessonIds.length}', emoji: '✅', color: KidColors.green)),
          ],
        ),
      ],
    );
  }
}

class _RewardBox extends StatelessWidget {
  final String title;
  final String value;
  final String emoji;
  final Color color;
  const _RewardBox({required this.title, required this.value, required this.emoji, required this.color});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      radius: 28,
      gradient: [Colors.white, color.withOpacity(.08)],
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 32)),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: color)),
          const SizedBox(height: 4),
          Text(title, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _BagTab extends StatelessWidget {
  final ProgressModel progress;
  const _BagTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('کیفِ من', emoji: '🎒'),
        const SizedBox(height: 14),
        KidCard(
          radius: 34,
          gradient: const [Color(0xFFF0F8FF), Color(0xFFFFF4E6)],
          child: Column(
            children: [
              Container(
                width: 94,
                height: 94,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30)),
                child: const Center(child: Text('🧒', style: TextStyle(fontSize: 56))),
              ),
              const SizedBox(height: 12),
              const Text('دانش‌آموز کلاس مهر', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: KidColors.ink)),
              const SizedBox(height: 6),
              const Text('من هر روز با شادی یاد می‌گیرم.', style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: _RewardBox(title: 'ستاره', value: '${progress.stars}', emoji: '⭐', color: KidColors.orange)),
                  const SizedBox(width: 12),
                  Expanded(child: _RewardBox(title: 'مرحله', value: '${progress.completedLessonIds.length}', emoji: '📘', color: KidColors.green)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _FriendTab extends StatelessWidget {
  final ProgressModel progress;
  const _FriendTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('من و دوستم', emoji: '🌈'),
        const SizedBox(height: 14),
        KidCard(
          radius: 34,
          gradient: const [Color(0xFFE8FDFF), Color(0xFFEFFFE8)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 70,
                    height: 70,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
                    child: const Text('🦁', style: TextStyle(fontSize: 42)),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('سلام دوست کوچولو!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: KidColors.ink)),
                        SizedBox(height: 4),
                        Text('من دوستِ تو در کلاس مهر هستم.', style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text('تو الان ${progress.stars} ستاره داری. هر درس تازه یعنی یک قدم دیگر برای قهرمان شدن.', style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.8)),
              const SizedBox(height: 14),
              Row(
                children: const [
                  Expanded(child: _MiniInfoTile(emoji: '🎧', label: 'گوش کن')),
                  SizedBox(width: 10),
                  Expanded(child: _MiniInfoTile(emoji: '✍️', label: 'تمرین کن')),
                  SizedBox(width: 10),
                  Expanded(child: _MiniInfoTile(emoji: '⭐', label: 'جایزه بگیر')),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MiniInfoTile extends StatelessWidget {
  final String emoji;
  final String label;
  const _MiniInfoTile({required this.emoji, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.88), borderRadius: BorderRadius.circular(20)),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 28)),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w900, color: KidColors.ink, fontSize: 12.3)),
        ],
      ),
    );
  }
}

class _KidBottomNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onChanged;
  const _KidBottomNav({required this.selectedIndex, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = [
      _NavEntry('خانه', '🏠', KidColors.blue),
      _NavEntry('نقشه', '🗺️', KidColors.deepBlue),
      _NavEntry('جایزه', '🎁', KidColors.purple),
      _NavEntry('کیف من', '🎒', KidColors.orange),
      _NavEntry('دوستم', '🌈', KidColors.green),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      child: Container(
        height: 84,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.97),
          borderRadius: BorderRadius.circular(34),
          border: Border.all(color: Colors.white, width: 1.4),
          boxShadow: [BoxShadow(blurRadius: 28, offset: const Offset(0, 14), color: Colors.black.withOpacity(.12))],
        ),
        child: Row(
          children: [
            for (int i = 0; i < items.length; i++) Expanded(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: () => onChanged(i), child: _BottomItem(item: items[i], selected: i == selectedIndex))),
          ],
        ),
      ),
    );
  }
}

class _NavEntry {
  final String label;
  final String emoji;
  final Color color;
  const _NavEntry(this.label, this.emoji, this.color);
}

class _BottomItem extends StatelessWidget {
  final _NavEntry item;
  final bool selected;
  const _BottomItem({required this.item, required this.selected});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(vertical: 7),
      decoration: BoxDecoration(color: selected ? item.color.withOpacity(.12) : Colors.transparent, borderRadius: BorderRadius.circular(24)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(item.emoji, style: TextStyle(fontSize: selected ? 24 : 22)),
          const SizedBox(height: 2),
          Text(item.label, style: TextStyle(color: selected ? item.color : KidColors.muted, fontSize: 11, fontWeight: selected ? FontWeight.w900 : FontWeight.w700)),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

class KidColors {
  static const ink = Color(0xFF12204A);
  static const muted = Color(0xFF6B6F88);
  static const sky = Color(0xFF38BDF8);
  static const blue = Color(0xFF2E7DFF);
  static const deepBlue = Color(0xFF1246A8);
  static const mint = Color(0xFFBFF5D2);
  static const green = Color(0xFF16A34A);
  static const yellow = Color(0xFFFFD95A);
  static const orange = Color(0xFFFF7A45);
  static const coral = Color(0xFFFF6B8A);
  static const purple = Color(0xFF8B5CF6);
  static const peach = Color(0xFFFFEEE5);
  static const lavender = Color(0xFFF0E8FF);
  static const cream = Color(0xFFFFF8EC);
  static const pageTop = Color(0xFFE5F7FF);
  static const pageBottom = Color(0xFFFFF7E9);
}

class KidScaffold extends StatelessWidget {
  final Widget child;
  final Widget? bottomNavigationBar;
  final bool safeArea;

  const KidScaffold({
    super.key,
    required this.child,
    this.bottomNavigationBar,
    this.safeArea = true,
  });

  @override
  Widget build(BuildContext context) {
    final content = Stack(
      children: [
        const Positioned.fill(child: PlayfulBackground()),
        child,
      ],
    );

    return Scaffold(
      extendBody: true,
      backgroundColor: KidColors.pageBottom,
      bottomNavigationBar: bottomNavigationBar,
      body: safeArea ? SafeArea(child: content) : content,
    );
  }
}

class PlayfulBackground extends StatelessWidget {
  const PlayfulBackground({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _PlayfulBackgroundPainter(),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [KidColors.pageTop, Colors.white, KidColors.pageBottom],
          ),
        ),
      ),
    );
  }
}

class _PlayfulBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cloudPaint = Paint()..color = Colors.white.withOpacity(.82);
    final blueSoft = Paint()..color = KidColors.blue.withOpacity(.06);
    final yellowSoft = Paint()..color = KidColors.yellow.withOpacity(.16);
    final purpleSoft = Paint()..color = KidColors.purple.withOpacity(.08);
    final hillOne = Paint()..color = const Color(0xFFE7FAD7);
    final hillTwo = Paint()..color = const Color(0xFFD8F7FF);

    // Clouds
    _cloud(canvas, Offset(size.width * .14, 42), cloudPaint, 1.0);
    _cloud(canvas, Offset(size.width * .82, 66), cloudPaint, 1.15);
    _cloud(canvas, Offset(size.width * .55, 28), cloudPaint, .8);

    // Soft circles
    canvas.drawCircle(Offset(size.width * .16, size.height * .28), 90, blueSoft);
    canvas.drawCircle(Offset(size.width * .92, size.height * .44), 74, yellowSoft);
    canvas.drawCircle(Offset(size.width * .10, size.height * .70), 86, purpleSoft);

    // Hills at bottom
    final path1 = Path()
      ..moveTo(0, size.height * .82)
      ..quadraticBezierTo(size.width * .18, size.height * .74, size.width * .36, size.height * .82)
      ..quadraticBezierTo(size.width * .58, size.height * .89, size.width * .78, size.height * .80)
      ..quadraticBezierTo(size.width * .92, size.height * .74, size.width, size.height * .80)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(path1, hillOne);

    final path2 = Path()
      ..moveTo(0, size.height * .88)
      ..quadraticBezierTo(size.width * .22, size.height * .80, size.width * .42, size.height * .88)
      ..quadraticBezierTo(size.width * .68, size.height * .96, size.width, size.height * .86)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(path2, hillTwo);

    // tiny stars / sparkles
    _sparkle(canvas, Offset(size.width * .30, 120), KidColors.yellow);
    _sparkle(canvas, Offset(size.width * .74, 136), KidColors.coral);
    _sparkle(canvas, Offset(size.width * .12, 210), KidColors.purple);
    _sparkle(canvas, Offset(size.width * .88, 250), KidColors.green);
  }

  void _cloud(Canvas canvas, Offset center, Paint paint, double scale) {
    canvas.drawCircle(center.translate(-20 * scale, 0), 22 * scale, paint);
    canvas.drawCircle(center.translate(10 * scale, -8 * scale), 28 * scale, paint);
    canvas.drawCircle(center.translate(40 * scale, 0), 22 * scale, paint);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: center.translate(12 * scale, 10 * scale), width: 90 * scale, height: 26 * scale),
        Radius.circular(16 * scale),
      ),
      paint,
    );
  }

  void _sparkle(Canvas canvas, Offset c, Color color) {
    final p = Paint()..color = color.withOpacity(.65);
    canvas.drawCircle(c, 4, p);
    canvas.drawRect(Rect.fromCenter(center: c, width: 14, height: 2), p);
    canvas.drawRect(Rect.fromCenter(center: c, width: 2, height: 14), p);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class KidCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final List<Color>? gradient;
  final Color? color;
  final Color? borderColor;
  final VoidCallback? onTap;
  final double radius;
  final double? minHeight;
  final bool strongShadow;

  const KidCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.gradient,
    this.color,
    this.borderColor,
    this.onTap,
    this.radius = 30,
    this.minHeight,
    this.strongShadow = false,
  });

  @override
  Widget build(BuildContext context) {
    final content = AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      constraints: minHeight == null ? null : BoxConstraints(minHeight: minHeight!),
      padding: padding,
      decoration: BoxDecoration(
        color: gradient == null ? (color ?? Colors.white) : null,
        gradient: gradient == null ? null : LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: gradient!),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor ?? Colors.white.withOpacity(.78), width: 1.5),
        boxShadow: [
          BoxShadow(
            blurRadius: strongShadow ? 34 : 24,
            offset: Offset(0, strongShadow ? 18 : 10),
            color: Colors.black.withOpacity(strongShadow ? .14 : .08),
          ),
          BoxShadow(
            blurRadius: 0,
            offset: const Offset(0, 2),
            color: Colors.white.withOpacity(.66),
          ),
        ],
      ),
      child: child,
    );

    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(radius),
        onTap: onTap,
        child: content,
      ),
    );
  }
}

class IconBubble extends StatelessWidget {
  final IconData? icon;
  final String? emoji;
  final Color color;
  final double size;
  final double iconSize;
  final Color? backgroundColor;

  const IconBubble({
    super.key,
    this.icon,
    this.emoji,
    required this.color,
    this.size = 64,
    this.iconSize = 34,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [backgroundColor ?? color.withOpacity(.16), Colors.white.withOpacity(.94)],
        ),
        borderRadius: BorderRadius.circular(size * .33),
        border: Border.all(color: Colors.white.withOpacity(.95), width: 1.2),
        boxShadow: [BoxShadow(blurRadius: 16, offset: const Offset(0, 8), color: color.withOpacity(.18))],
      ),
      child: emoji == null ? Icon(icon, color: color, size: iconSize) : Text(emoji!, style: TextStyle(fontSize: iconSize), textAlign: TextAlign.center),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String emoji;

  const SectionTitle(this.title, {super.key, this.emoji = '⭐'});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.86),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [BoxShadow(blurRadius: 12, offset: const Offset(0, 4), color: Colors.black.withOpacity(.05))],
          ),
          child: Text(emoji, style: const TextStyle(fontSize: 20)),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(title, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: KidColors.ink)),
        ),
        Container(width: 48, height: 6, decoration: BoxDecoration(color: KidColors.coral.withOpacity(.28), borderRadius: BorderRadius.circular(99))),
      ],
    );
  }
}

class PageShell extends StatelessWidget {
  final String title;
  final Widget child;
  final Widget? action;

  const PageShell({super.key, required this.title, required this.child, this.action});

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: KidScaffold(
          bottomNavigationBar: null,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
                child: Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [BoxShadow(blurRadius: 16, offset: const Offset(0, 8), color: Colors.black.withOpacity(.08))],
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.arrow_back_rounded, color: KidColors.deepBlue),
                        onPressed: () => Navigator.maybePop(context),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(.86),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            const Text('🎈', style: TextStyle(fontSize: 20)),
                            const SizedBox(width: 8),
                            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: KidColors.ink, fontSize: 21))),
                          ],
                        ),
                      ),
                    ),
                    if (action != null) ...[
                      const SizedBox(width: 10),
                      action!,
                    ],
                  ],
                ),
              ),
              Expanded(child: child),
            ],
          ),
        ),
      );
}

class SoftPill extends StatelessWidget {
  final Widget child;
  final Color color;
  final EdgeInsets padding;

  const SoftPill({super.key, required this.child, required this.color, this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 8)});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color.withOpacity(.13),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(.18)),
      ),
      child: child,
    );
  }
}

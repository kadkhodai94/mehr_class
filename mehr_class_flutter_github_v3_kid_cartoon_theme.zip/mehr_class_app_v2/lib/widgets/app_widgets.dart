import 'package:flutter/material.dart';

class KidColors {
  static const ink = Color(0xFF12204A);
  static const muted = Color(0xFF6B6F88);
  static const sky = Color(0xFF38BDF8);
  static const blue = Color(0xFF2E7DFF);
  static const deepBlue = Color(0xFF1246A8);
  static const mint = Color(0xFFBFF5D2);
  static const green = Color(0xFF16A34A);
  static const yellow = Color(0xFFFFD95A);
  static const orange = Color(0xFFFF7A45);
  static const coral = Color(0xFFFF6B8A);
  static const purple = Color(0xFF8B5CF6);
  static const peach = Color(0xFFFFEEE5);
  static const lavender = Color(0xFFF0E8FF);
  static const cream = Color(0xFFFFF8EC);
  static const pageTop = Color(0xFFE9F8FF);
  static const pageBottom = Color(0xFFFFF7EA);
}

class KidScaffold extends StatelessWidget {
  final Widget child;
  final Widget? bottomNavigationBar;
  final bool safeArea;

  const KidScaffold({
    super.key,
    required this.child,
    this.bottomNavigationBar,
    this.safeArea = true,
  });

  @override
  Widget build(BuildContext context) {
    final content = Stack(
      children: [
        const Positioned.fill(child: PlayfulBackground()),
        child,
      ],
    );

    return Scaffold(
      extendBody: true,
      backgroundColor: KidColors.pageBottom,
      bottomNavigationBar: bottomNavigationBar,
      body: safeArea ? SafeArea(child: content) : content,
    );
  }
}

class PlayfulBackground extends StatelessWidget {
  const PlayfulBackground({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _PlayfulBackgroundPainter(),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [KidColors.pageTop, Colors.white, KidColors.pageBottom],
          ),
        ),
      ),
    );
  }
}

class _PlayfulBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cloudPaint = Paint()..color = Colors.white.withOpacity(.74);
    final softPaint = Paint()..color = KidColors.blue.withOpacity(.07);
    final yellowPaint = Paint()..color = KidColors.yellow.withOpacity(.18);
    final purplePaint = Paint()..color = KidColors.purple.withOpacity(.08);

    canvas.drawCircle(Offset(size.width * .08, 24), 34, cloudPaint);
    canvas.drawCircle(Offset(size.width * .20, 48), 26, cloudPaint);
    canvas.drawCircle(Offset(size.width * .33, 28), 46, cloudPaint);
    canvas.drawCircle(Offset(size.width * .91, 30), 68, cloudPaint);
    canvas.drawCircle(Offset(size.width * .78, 90), 45, cloudPaint);

    canvas.drawCircle(Offset(size.width * .16, size.height * .30), 90, softPaint);
    canvas.drawCircle(Offset(size.width * .92, size.height * .46), 70, yellowPaint);
    canvas.drawCircle(Offset(size.width * .12, size.height * .72), 72, purplePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class KidCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final List<Color>? gradient;
  final Color? color;
  final Color? borderColor;
  final VoidCallback? onTap;
  final double radius;
  final double? minHeight;
  final bool strongShadow;

  const KidCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.gradient,
    this.color,
    this.borderColor,
    this.onTap,
    this.radius = 30,
    this.minHeight,
    this.strongShadow = false,
  });

  @override
  Widget build(BuildContext context) {
    final content = AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      constraints: minHeight == null ? null : BoxConstraints(minHeight: minHeight!),
      padding: padding,
      decoration: BoxDecoration(
        color: gradient == null ? (color ?? Colors.white) : null,
        gradient: gradient == null ? null : LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: gradient!),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor ?? Colors.white.withOpacity(.70), width: 1.4),
        boxShadow: [
          BoxShadow(
            blurRadius: strongShadow ? 30 : 22,
            offset: Offset(0, strongShadow ? 16 : 10),
            color: Colors.black.withOpacity(strongShadow ? .13 : .08),
          ),
          BoxShadow(
            blurRadius: 0,
            offset: const Offset(0, 2),
            color: Colors.white.withOpacity(.66),
          ),
        ],
      ),
      child: child,
    );

    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(radius),
        onTap: onTap,
        child: content,
      ),
    );
  }
}

class PremiumCard extends KidCard {
  const PremiumCard({
    super.key,
    required super.child,
    super.padding,
    super.gradient,
    super.color,
    super.borderColor,
    super.onTap,
    super.radius,
    super.minHeight,
    super.strongShadow,
  });
}

class IconBubble extends StatelessWidget {
  final IconData? icon;
  final String? emoji;
  final Color color;
  final double size;
  final double iconSize;
  final Color? backgroundColor;

  const IconBubble({
    super.key,
    this.icon,
    this.emoji,
    required this.color,
    this.size = 64,
    this.iconSize = 34,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [backgroundColor ?? color.withOpacity(.16), Colors.white.withOpacity(.92)],
        ),
        borderRadius: BorderRadius.circular(size * .33),
        border: Border.all(color: Colors.white.withOpacity(.9), width: 1.2),
        boxShadow: [BoxShadow(blurRadius: 16, offset: const Offset(0, 8), color: color.withOpacity(.18))],
      ),
      child: emoji == null
          ? Icon(icon, color: color, size: iconSize)
          : Text(emoji!, style: TextStyle(fontSize: iconSize), textAlign: TextAlign.center),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String emoji;

  const SectionTitle(this.title, {super.key, this.emoji = '⭐'});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: KidColors.ink)),
        const SizedBox(width: 8),
        Text(emoji, style: const TextStyle(fontSize: 22)),
        const Spacer(),
        Container(width: 42, height: 4, decoration: BoxDecoration(color: KidColors.coral.withOpacity(.35), borderRadius: BorderRadius.circular(99))),
      ],
    );
  }
}

class PageShell extends StatelessWidget {
  final String title;
  final Widget child;
  final Widget? action;

  const PageShell({super.key, required this.title, required this.child, this.action});

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: KidScaffold(
          bottomNavigationBar: null,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
                child: Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [BoxShadow(blurRadius: 16, offset: const Offset(0, 8), color: Colors.black.withOpacity(.08))],
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.arrow_back_rounded, color: KidColors.deepBlue),
                        onPressed: () => Navigator.maybePop(context),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: KidColors.ink, fontSize: 23))),
                    if (action != null) action!,
                  ],
                ),
              ),
              Expanded(child: child),
            ],
          ),
        ),
      );
}

class SoftPill extends StatelessWidget {
  final Widget child;
  final Color color;
  final EdgeInsets padding;

  const SoftPill({super.key, required this.child, required this.color, this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 8)});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color.withOpacity(.13),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(.18)),
      ),
      child: child,
    );
  }
}

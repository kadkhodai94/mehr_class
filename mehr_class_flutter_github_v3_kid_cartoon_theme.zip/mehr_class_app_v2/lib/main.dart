import 'package:flutter/material.dart';

import 'data/offline_content.dart';
import 'models/lesson_models.dart';
import 'services/app_audio.dart';
import 'services/progress_store.dart';
import 'services/sync_service.dart';
import 'widgets/app_widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MehrClassApp());
}

class MehrClassApp extends StatelessWidget {
  const MehrClassApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کلاس مهر',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: KidColors.blue),
        textTheme: Theme.of(context).textTheme.apply(
              bodyColor: KidColors.ink,
              displayColor: KidColors.ink,
              fontFamily: 'sans',
            ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: KidColors.blue,
            foregroundColor: Colors.white,
            elevation: 0,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: KidColors.deepBlue,
            side: BorderSide(color: KidColors.blue.withOpacity(.25), width: 1.4),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  ProgressModel progress = ProgressModel.empty();
  bool syncing = false;
  int tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _sync() async {
    setState(() => syncing = true);
    final result = await const SyncService().checkForContentUpdates();
    if (!mounted) return;
    setState(() => syncing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(result.message, textDirection: TextDirection.rtl),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: KidScaffold(
        bottomNavigationBar: _KidBottomNav(
          selectedIndex: tabIndex,
          onChanged: (value) => setState(() => tabIndex = value),
        ),
        child: IndexedStack(
          index: tabIndex,
          children: [
            _HomeTab(progress: progress, syncing: syncing, onSync: _sync, onChanged: _load),
            _LessonsHub(onChanged: _load),
            _RewardsTab(stars: progress.stars),
            _ProfileTab(completed: progress.completedLessonIds.length, stars: progress.stars),
            _MeTab(stars: progress.stars),
          ],
        ),
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  final ProgressModel progress;
  final bool syncing;
  final VoidCallback onSync;
  final VoidCallback onChanged;

  const _HomeTab({required this.progress, required this.syncing, required this.onSync, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 104),
      children: [
        _Header(stars: progress.stars),
        const SizedBox(height: 20),
        _HeroCard(onPlay: () => AppAudio.playAsset(OfflineContent.commonWelcome.localAssetPath)),
        const SizedBox(height: 18),
        _OfflineNotice(syncing: syncing, onSync: onSync),
        const SizedBox(height: 22),
        const SectionTitle('انتخاب پایه', emoji: '⭐'),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: _GradeCard(
                title: 'پایه اول',
                subtitle: 'درس‌های اول',
                emoji: '🌱',
                gradient: const [Color(0xFFE7FFD8), Color(0xFFBAF4C3)],
                titleColor: const Color(0xFF16803A),
                grade: GradeLevel.gradeOne,
                onChanged: onChanged,
              ),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: _GradeCard(
                title: 'پایه دوم',
                subtitle: 'درس‌های دوم',
                emoji: '🚀',
                gradient: const [Color(0xFFE1F8FF), Color(0xFFABE4FF)],
                titleColor: KidColors.deepBlue,
                grade: GradeLevel.gradeTwo,
                onChanged: onChanged,
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle('بخش‌های آموزشی', emoji: '✏️'),
        const SizedBox(height: 14),
        _MenuGrid(onChanged: onChanged),
        const SizedBox(height: 18),
        _LearningPath(completed: progress.completedLessonIds.length),
      ],
    );
  }
}

class _Header extends StatelessWidget {
  final int stars;
  const _Header({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 66,
          height: 66,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF0EA5FF), Color(0xFF2457FF)]),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [BoxShadow(blurRadius: 22, offset: const Offset(0, 12), color: KidColors.blue.withOpacity(.26))],
          ),
          child: const Icon(Icons.school_rounded, color: Colors.white, size: 38),
        ),
        const SizedBox(width: 13),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('کلاس مهر', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: KidColors.ink, letterSpacing: -.4)),
              SizedBox(height: 4),
              Text('آفلاین، سبک، آماده اتصال به پنل', style: TextStyle(fontSize: 13, color: KidColors.muted, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFFF7D2), Color(0xFFFFE38E)]),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white, width: 1.2),
            boxShadow: [BoxShadow(blurRadius: 16, offset: const Offset(0, 8), color: KidColors.yellow.withOpacity(.26))],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('$stars', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: KidColors.ink)),
              const SizedBox(width: 7),
              const Icon(Icons.star_rounded, color: Color(0xFFFFB300), size: 29),
            ],
          ),
        ),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  final VoidCallback onPlay;
  const _HeroCard({required this.onPlay});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      padding: EdgeInsets.zero,
      radius: 36,
      strongShadow: true,
      gradient: const [Color(0xFF0284FF), Color(0xFF20D3FF)],
      child: Stack(
        children: [
          const Positioned(top: 20, right: 22, child: Text('☁️', style: TextStyle(fontSize: 42))),
          const Positioned(top: 58, right: 70, child: Text('🌈', style: TextStyle(fontSize: 48))),
          const Positioned(top: 70, left: 28, child: Text('🦋', style: TextStyle(fontSize: 26))),
          const Positioned(bottom: 20, right: 18, child: Text('🌼', style: TextStyle(fontSize: 26))),
          const Positioned(bottom: 12, left: 18, child: Text('⭐', style: TextStyle(fontSize: 23))),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'سلام قهرمان کوچولو!',
                        style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900, height: 1.25, shadows: [Shadow(blurRadius: 0, offset: Offset(0, 2), color: Color(0x22000000))]),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'اینجا با صدا، تصویر و بازی،\nحروف، عددها و مهارت‌های زندگی را یاد می‌گیریم.',
                        style: TextStyle(color: Colors.white, height: 1.85, fontSize: 15.5, fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          ElevatedButton.icon(
                            onPressed: onPlay,
                            icon: const Icon(Icons.volume_up_rounded, size: 24),
                            label: const Text('پخش ویس'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: KidColors.deepBlue,
                              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Text('ویس‌ها بعداً با صدای خودت جایگزین می‌شوند.', style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w700, height: 1.5)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 102,
                  height: 118,
                  alignment: Alignment.bottomCenter,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.20),
                    borderRadius: BorderRadius.circular(34),
                    border: Border.all(color: Colors.white.withOpacity(.55)),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(bottom: 6),
                    child: Text('🦁', style: TextStyle(fontSize: 78)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _OfflineNotice extends StatelessWidget {
  final bool syncing;
  final VoidCallback onSync;
  const _OfflineNotice({required this.syncing, required this.onSync});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      padding: const EdgeInsets.fromLTRB(14, 14, 16, 14),
      color: Colors.white,
      radius: 28,
      child: Row(
        children: [
          const IconBubble(emoji: '🍏', color: KidColors.green, size: 58, iconSize: 34, backgroundColor: Color(0xFFE9FFE9)),
          const SizedBox(width: 12),
          const Expanded(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(text: 'نسخه فعلی بدون اینترنت کار می‌کند.\n'),
                  TextSpan(text: 'ساختار ', style: TextStyle(fontWeight: FontWeight.w800)),
                  TextSpan(text: 'sync', style: TextStyle(color: KidColors.green, fontWeight: FontWeight.w900)),
                  TextSpan(text: ' برای پنل آینده آماده است.'),
                ],
              ),
              style: TextStyle(fontWeight: FontWeight.w800, height: 1.75, fontSize: 14.6, color: KidColors.ink),
            ),
          ),
          TextButton(
            onPressed: syncing ? null : onSync,
            child: Text(syncing ? 'بررسی...' : 'بررسی', style: const TextStyle(fontWeight: FontWeight.w900)),
          ),
          Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFFE8FCEB), borderRadius: BorderRadius.circular(17)),
            child: const Icon(Icons.cloud_done_rounded, color: KidColors.green, size: 30),
          ),
        ],
      ),
    );
  }
}

class _GradeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String emoji;
  final List<Color> gradient;
  final Color titleColor;
  final GradeLevel grade;
  final VoidCallback onChanged;

  const _GradeCard({required this.title, required this.subtitle, required this.emoji, required this.gradient, required this.titleColor, required this.grade, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final lessons = OfflineContent.lessons.where((e) => e.grade == grade).toList();
    return KidCard(
      minHeight: 150,
      padding: const EdgeInsets.all(16),
      gradient: gradient,
      radius: 30,
      borderColor: Colors.white,
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonsListPage(title: title, lessons: lessons, onChanged: onChanged))),
      child: Stack(
        children: [
          const Positioned(top: 0, left: 4, child: Text('☁️', style: TextStyle(fontSize: 24))),
          Positioned(bottom: 0, right: 0, child: Text(emoji, style: const TextStyle(fontSize: 60))),
          Align(
            alignment: Alignment.centerLeft,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 25, color: titleColor, height: 1.15)),
                const SizedBox(height: 6),
                Text(subtitle, style: TextStyle(fontWeight: FontWeight.w800, color: titleColor.withOpacity(.78), fontSize: 14.5)),
                const SizedBox(height: 10),
                SoftPill(
                  color: titleColor,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  child: Text('${lessons.length} درس', style: TextStyle(color: titleColor, fontWeight: FontWeight.w900, fontSize: 12)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuGrid extends StatelessWidget {
  final VoidCallback onChanged;
  const _MenuGrid({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = [
      _MenuItem('حروف فارسی', 'ب', Icons.abc_rounded, KidColors.purple, const [Color(0xFFF5E8FF), Color(0xFFE8DBFF)], LessonType.letters),
      _MenuItem('اعداد و ریاضی', '۲۳', Icons.calculate_rounded, KidColors.orange, const [Color(0xFFFFEFE7), Color(0xFFFFD8C7)], LessonType.numbers),
      _MenuItem('قصه و رنگ‌آمیزی', '📚', Icons.menu_book_rounded, const Color(0xFFE69A00), const [Color(0xFFFFF6D8), Color(0xFFFFE2A4)], LessonType.story),
      _MenuItem('مهارت زندگی', '🧼', Icons.favorite_rounded, KidColors.coral, const [Color(0xFFFFEAF0), Color(0xFFFFD3DF)], LessonType.lifeSkill),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 13, crossAxisSpacing: 13, childAspectRatio: .95),
      itemBuilder: (_, i) => _MenuCard(item: items[i], onChanged: onChanged),
    );
  }
}

class _MenuItem {
  final String title;
  final String label;
  final IconData icon;
  final Color color;
  final List<Color> gradient;
  final LessonType type;
  const _MenuItem(this.title, this.label, this.icon, this.color, this.gradient, this.type);
}

class _MenuCard extends StatelessWidget {
  final _MenuItem item;
  final VoidCallback onChanged;
  const _MenuCard({required this.item, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final lessons = OfflineContent.lessons.where((e) => e.type == item.type || (item.type == LessonType.numbers && e.type == LessonType.math)).toList();
    return KidCard(
      gradient: item.gradient,
      radius: 30,
      padding: const EdgeInsets.all(14),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonsListPage(title: item.title, lessons: lessons, onChanged: onChanged))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              IconBubble(icon: item.icon, emoji: item.label.length <= 2 ? null : item.label, color: item.color, size: 70, iconSize: 36),
              if (item.label.length <= 2)
                Text(item.label, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: item.color)),
              const Positioned(top: -10, left: -6, child: Text('⭐', style: TextStyle(fontSize: 18))),
            ],
          ),
          const SizedBox(height: 16),
          Text(item.title, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: item.color), textAlign: TextAlign.center),
          const SizedBox(height: 8),
          SoftPill(
            color: item.color,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Text('${lessons.length} درس', style: TextStyle(color: item.color, fontWeight: FontWeight.w900, fontSize: 12)),
          ),
        ],
      ),
    );
  }
}

class _LearningPath extends StatelessWidget {
  final int completed;
  const _LearningPath({required this.completed});

  @override
  Widget build(BuildContext context) {
    final steps = [
      ('گوش کن', '🎧', KidColors.blue),
      ('با انگشت تمرین کن', '✍️', KidColors.purple),
      ('جواب بده', '💡', KidColors.orange),
      ('ستاره بگیر', '⭐', KidColors.green),
    ];
    return KidCard(
      padding: const EdgeInsets.all(18),
      radius: 32,
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('مسیر یادگیری', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: KidColors.ink))),
              SoftPill(
                color: KidColors.green,
                child: Text('$completed درس کامل شده', style: const TextStyle(color: KidColors.green, fontWeight: FontWeight.w900, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          for (int i = 0; i < steps.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  IconBubble(emoji: steps[i].$2, color: steps[i].$3, size: 48, iconSize: 25),
                  const SizedBox(width: 12),
                  Expanded(child: Text(steps[i].$1, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15))),
                  Container(
                    width: 26,
                    height: 26,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: steps[i].$3.withOpacity(.12), borderRadius: BorderRadius.circular(10)),
                    child: Text('${i + 1}', style: TextStyle(color: steps[i].$3, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class LessonsListPage extends StatefulWidget {
  final String title;
  final List<LessonModel> lessons;
  final VoidCallback onChanged;

  const LessonsListPage({super.key, required this.title, required this.lessons, required this.onChanged});

  @override
  State<LessonsListPage> createState() => _LessonsListPageState();
}

class _LessonsListPageState extends State<LessonsListPage> {
  ProgressModel progress = ProgressModel.empty();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _complete(LessonModel lesson) async {
    progress = await ProgressStore.completeLesson(lesson.id);
    await AppAudio.playAsset('assets/audio/common/correct.mp3');
    widget.onChanged();
    if (mounted) setState(() {});
  }

  Color _lessonColor(LessonModel lesson) {
    switch (lesson.type) {
      case LessonType.letters:
        return KidColors.purple;
      case LessonType.numbers:
      case LessonType.math:
        return KidColors.orange;
      case LessonType.story:
        return const Color(0xFFE69A00);
      case LessonType.lifeSkill:
        return KidColors.green;
      case LessonType.writing:
        return KidColors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageShell(
      title: widget.title,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 26),
        itemCount: widget.lessons.length,
        separatorBuilder: (_, __) => const SizedBox(height: 14),
        itemBuilder: (_, i) {
          final lesson = widget.lessons[i];
          final done = progress.completedLessonIds.contains(lesson.id);
          final color = _lessonColor(lesson);
          return KidCard(
            padding: const EdgeInsets.all(16),
            radius: 30,
            borderColor: color.withOpacity(.10),
            gradient: [Colors.white, color.withOpacity(.06)],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 76,
                      height: 76,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [color.withOpacity(.18), Colors.white]),
                        borderRadius: BorderRadius.circular(26),
                        border: Border.all(color: Colors.white, width: 1.2),
                        boxShadow: [BoxShadow(blurRadius: 16, offset: const Offset(0, 8), color: color.withOpacity(.14))],
                      ),
                      child: Text(lesson.display, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: color)),
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19, color: KidColors.ink)),
                          const SizedBox(height: 5),
                          Text(lesson.subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.5)),
                        ],
                      ),
                    ),
                    Icon(done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, color: done ? KidColors.green : KidColors.muted, size: 29),
                  ],
                ),
                if (lesson.examples.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: lesson.examples
                        .map((e) => SoftPill(
                              color: color,
                              child: Text(e, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
                            ))
                        .toList(),
                  ),
                ],
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(child: OutlinedButton.icon(onPressed: lesson.audio == null ? null : () => AppAudio.playAsset(lesson.audio!.localAssetPath), icon: const Icon(Icons.volume_up_rounded), label: const Text('پخش ویس'))),
                    const SizedBox(width: 10),
                    Expanded(child: ElevatedButton.icon(onPressed: () => _complete(lesson), icon: const Icon(Icons.star_rounded), label: Text(done ? 'تکرار شد' : 'یاد گرفتم'))),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _LessonsHub extends StatelessWidget {
  final VoidCallback onChanged;
  const _LessonsHub({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 104),
      children: [
        const SectionTitle('همه درس‌ها', emoji: '📚'),
        const SizedBox(height: 16),
        _MenuGrid(onChanged: onChanged),
      ],
    );
  }
}

class _RewardsTab extends StatelessWidget {
  final int stars;
  const _RewardsTab({required this.stars});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 104),
      children: [
        const SectionTitle('جایزه‌ها', emoji: '🎁'),
        const SizedBox(height: 16),
        KidCard(
          gradient: const [Color(0xFFFFF3B0), Color(0xFFFFD36A)],
          child: Column(
            children: [
              const Text('🏆', style: TextStyle(fontSize: 72)),
              const SizedBox(height: 8),
              const Text('قهرمان یادگیری', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: KidColors.ink)),
              const SizedBox(height: 8),
              Text('تا الان $stars ستاره گرفتی.', style: const TextStyle(fontWeight: FontWeight.w800, color: KidColors.muted)),
            ],
          ),
        ),
      ],
    );
  }
}

class _ProfileTab extends StatelessWidget {
  final int completed;
  final int stars;
  const _ProfileTab({required this.completed, required this.stars});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 104),
      children: [
        const SectionTitle('پروفایل', emoji: '🎒'),
        const SizedBox(height: 16),
        KidCard(
          child: Column(
            children: [
              const Text('👧🏻👦🏻', style: TextStyle(fontSize: 62)),
              const SizedBox(height: 8),
              const Text('دانش‌آموز کلاس مهر', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: _TinyStat(title: 'درس کامل', value: '$completed', color: KidColors.green, emoji: '✅')),
                  const SizedBox(width: 12),
                  Expanded(child: _TinyStat(title: 'ستاره', value: '$stars', color: KidColors.orange, emoji: '⭐')),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MeTab extends StatelessWidget {
  final int stars;
  const _MeTab({required this.stars});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 104),
      children: [
        const SectionTitle('من', emoji: '🌟'),
        const SizedBox(height: 16),
        KidCard(
          gradient: const [Color(0xFFE8FFE8), Color(0xFFD5F6FF)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('سلام دوست کوچولو!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: KidColors.ink)),
              const SizedBox(height: 10),
              Text('تو $stars ستاره داری. هر درس جدید یعنی یک قدم نزدیک‌تر به قهرمان شدن.', style: const TextStyle(fontWeight: FontWeight.w800, color: KidColors.muted, height: 1.8)),
            ],
          ),
        ),
      ],
    );
  }
}

class _TinyStat extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  final String emoji;

  const _TinyStat({required this.title, required this.value, required this.color, required this.emoji});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: color.withOpacity(.10), borderRadius: BorderRadius.circular(24)),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 28)),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 24)),
          const SizedBox(height: 4),
          Text(title, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w800, fontSize: 12)),
        ],
      ),
    );
  }
}

class _KidBottomNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onChanged;

  const _KidBottomNav({required this.selectedIndex, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = [
      _NavItem('خانه', Icons.home_rounded, KidColors.blue),
      _NavItem('درس‌ها', Icons.list_alt_rounded, KidColors.deepBlue),
      _NavItem('جایزه‌ها', Icons.stars_rounded, KidColors.purple),
      _NavItem('پروفایل', Icons.backpack_rounded, KidColors.orange),
      _NavItem('من', Icons.face_rounded, KidColors.green),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      child: Container(
        height: 78,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.96),
          borderRadius: BorderRadius.circular(34),
          border: Border.all(color: Colors.white, width: 1.4),
          boxShadow: [BoxShadow(blurRadius: 28, offset: const Offset(0, 12), color: Colors.black.withOpacity(.12))],
        ),
        child: Row(
          children: [
            for (int i = 0; i < items.length; i++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onChanged(i),
                  child: _NavButton(item: items[i], selected: i == selectedIndex),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NavItem {
  final String label;
  final IconData icon;
  final Color color;
  const _NavItem(this.label, this.icon, this.color);
}

class _NavButton extends StatelessWidget {
  final _NavItem item;
  final bool selected;

  const _NavButton({required this.item, required this.selected});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(vertical: 7),
      decoration: BoxDecoration(
        color: selected ? item.color.withOpacity(.12) : Colors.transparent,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(item.icon, color: selected ? item.color : KidColors.muted, size: selected ? 28 : 24),
          const SizedBox(height: 3),
          Text(item.label, style: TextStyle(color: selected ? item.color : KidColors.muted, fontSize: 11, fontWeight: selected ? FontWeight.w900 : FontWeight.w700)),
        ],
      ),
    );
  }
}

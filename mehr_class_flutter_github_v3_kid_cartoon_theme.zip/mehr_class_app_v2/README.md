# کلاس مهر - نسخه 1.2.0

اپ آموزشی آفلاین برای دانش‌آموزان پایه اول و دوم، مخصوص کودکان زیر ۱۰ سال و مناسب گوشی‌های ضعیف.

## تغییرات نسخه 1.2.0

- بازطراحی کامل تم بر اساس سبک کودکانه، شاد و کارتونی.
- اضافه شدن صفحه اصلی رنگی با بنر قهرمان کوچولو، کارت‌های فانتزی، آیکن‌های نرم و کودک‌پسند.
- اضافه شدن منوی پایین کارتونی: خانه، درس‌ها، جایزه‌ها، پروفایل و من.
- بازطراحی کارت‌های انتخاب پایه اول و دوم.
- بازطراحی کارت‌های بخش‌های آموزشی: حروف فارسی، اعداد و ریاضی، قصه و رنگ‌آمیزی، مهارت زندگی.
- حفظ معماری آفلاین و آماده اتصال به بک‌اند آینده.
- حفظ جایگاه فایل‌های صوتی برای ویس‌های ضبط‌شده کاربر.
- Workflow جدید برای ساخت پروژه Flutter تمیز و رفع خطای unsupported Gradle project.

## مسیر ویس‌ها

فایل‌های صوتی را با همین نام‌ها داخل مسیرهای زیر قرار بدهید:

```text
assets/audio/common/
assets/audio/letters/
assets/audio/numbers/
assets/audio/stories/
assets/audio/life/
```

نمونه:

```text
assets/audio/common/welcome.mp3
assets/audio/common/correct.mp3
assets/audio/letters/alef.mp3
assets/audio/letters/be.mp3
assets/audio/numbers/number_1.mp3
```

## Workflow

مسیر قرارگیری workflow:

```text
.github/workflows/build.yml
```

این workflow اگر ZIP داخل ریشه ریپو باشد، آخرین ZIP را باز می‌کند، یک پروژه Flutter سالم می‌سازد، فایل‌های `lib`، `assets` و `pubspec.yaml` را منتقل می‌کند و خروجی APK/AAB می‌گیرد.

# کلاس مهر - نسخه 1.1.0

اپ آموزشی آفلاین برای پایه اول و دوم، مخصوص دانش‌آموزان مناطق محروم.

## ویژگی‌ها
- اجرای کامل بدون اینترنت
- ساختار آماده برای بک‌اند و پنل مدیریت آینده
- مدل درس، صدا، دسته‌بندی و پیشرفت
- ذخیره پیشرفت کودک روی گوشی
- جایگذاری ویس‌ها داخل assets
- UI کودکانه و حرفه‌ای‌تر نسبت به نسخه اول

## مسیر ویس‌ها
فایل‌ها را با همین نام‌ها داخل پوشه‌ها قرار بده:

### common
- assets/audio/common/welcome.mp3
- assets/audio/common/correct.mp3
- assets/audio/common/wrong.mp3
- assets/audio/common/try_again.mp3

### letters
- assets/audio/letters/alef.mp3
- assets/audio/letters/be.mp3
- assets/audio/letters/pe.mp3

### numbers
- assets/audio/numbers/number_1.mp3
- assets/audio/numbers/number_2.mp3
- assets/audio/numbers/count_start.mp3

### stories
- assets/audio/stories/story_book.mp3

### life
- assets/audio/life/wash_hands.mp3

## بک‌اند آینده
فایل `lib/services/sync_service.dart` فعلاً خاموش است، اما ساختار اتصال به پنل، دریافت درس جدید، ویس جدید و بسته آفلاین آماده شده است.

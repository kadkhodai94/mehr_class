import 'package:flutter/material.dart';

class PremiumCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final List<Color>? gradient;
  final VoidCallback? onTap;

  const PremiumCard({super.key, required this.child, this.padding = const EdgeInsets.all(18), this.gradient, this.onTap});

  @override
  Widget build(BuildContext context) {
    final content = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: gradient == null ? Colors.white : null,
        gradient: gradient == null ? null : LinearGradient(colors: gradient!),
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(blurRadius: 24, offset: Offset(0, 14), color: Color(0x18000000)),
          BoxShadow(blurRadius: 1, offset: Offset(0, 1), color: Color(0x11000000)),
        ],
      ),
      child: child,
    );
    if (onTap == null) return content;
    return InkWell(borderRadius: BorderRadius.circular(28), onTap: onTap, child: content);
  }
}

class PageShell extends StatelessWidget {
  final String title;
  final Widget child;
  final Widget? action;

  const PageShell({super.key, required this.title, required this.child, this.action});

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: const Color(0xFFF8F1E7),
          appBar: AppBar(
            backgroundColor: const Color(0xFFF8F1E7),
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            actions: action == null ? null : [Padding(padding: const EdgeInsets.only(left: 12), child: action!)],
          ),
          body: child,
        ),
      );
}

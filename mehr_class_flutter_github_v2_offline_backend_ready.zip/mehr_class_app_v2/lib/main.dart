import 'package:flutter/material.dart';

import 'data/offline_content.dart';
import 'models/lesson_models.dart';
import 'services/app_audio.dart';
import 'services/progress_store.dart';
import 'services/sync_service.dart';
import 'widgets/app_widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MehrClassApp());
}

class MehrClassApp extends StatelessWidget {
  const MehrClassApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کلاس مهر',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7DFF)),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  ProgressModel progress = ProgressModel.empty();
  bool syncing = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _sync() async {
    setState(() => syncing = true);
    final result = await const SyncService().checkForContentUpdates();
    if (!mounted) return;
    setState(() => syncing = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.message)));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F1E7),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              _Header(stars: progress.stars),
              const SizedBox(height: 18),
              _HeroCard(onPlay: () => AppAudio.playAsset(OfflineContent.commonWelcome.localAssetPath)),
              const SizedBox(height: 18),
              _OfflineNotice(syncing: syncing, onSync: _sync),
              const SizedBox(height: 18),
              const _SectionTitle('انتخاب پایه'),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _GradeCard(title: 'پایه اول', emoji: '🌱', color: const Color(0xFF2E7DFF), grade: GradeLevel.gradeOne, onChanged: _load)),
                  const SizedBox(width: 12),
                  Expanded(child: _GradeCard(title: 'پایه دوم', emoji: '🚀', color: const Color(0xFF00A86B), grade: GradeLevel.gradeTwo, onChanged: _load)),
                ],
              ),
              const SizedBox(height: 18),
              const _SectionTitle('بخش‌های آموزشی'),
              const SizedBox(height: 12),
              _MenuGrid(onChanged: _load),
              const SizedBox(height: 18),
              _LearningPath(completed: progress.completedLessonIds.length),
            ],
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final int stars;
  const _Header({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 58,
          height: 58,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF2E7DFF), Color(0xFF57C7FF)]),
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(blurRadius: 18, offset: Offset(0, 10), color: Color(0x332E7DFF))],
          ),
          child: const Icon(Icons.school_rounded, color: Colors.white, size: 33),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('کلاس مهر', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
              SizedBox(height: 3),
              Text('آفلاین، سبک، آماده اتصال به پنل', style: TextStyle(fontSize: 13, color: Color(0xFF6F665D))),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
          decoration: BoxDecoration(color: const Color(0xFFFFF2BD), borderRadius: BorderRadius.circular(18)),
          child: Row(children: [const Icon(Icons.star_rounded, color: Color(0xFFFFB300)), const SizedBox(width: 4), Text('$stars', style: const TextStyle(fontWeight: FontWeight.w900))]),
        ),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  final VoidCallback onPlay;
  const _HeroCard({required this.onPlay});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      gradient: const [Color(0xFF2E7DFF), Color(0xFF57C7FF)],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('سلام قهرمان کوچولو!', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('اینجا با صدا، تصویر و بازی، حروف، عددها و مهارت‌های زندگی را یاد می‌گیریم.', style: TextStyle(color: Colors.white, height: 1.8, fontSize: 14.5)),
        const SizedBox(height: 16),
        Row(children: [
          ElevatedButton.icon(
            onPressed: onPlay,
            icon: const Icon(Icons.volume_up_rounded),
            label: const Text('پخش ویس'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF2E7DFF)),
          ),
          const SizedBox(width: 10),
          const Expanded(child: Text('ویس‌ها بعداً با صدای خودت جایگزین می‌شوند.', style: TextStyle(color: Colors.white, fontSize: 12))),
        ]),
      ]),
    );
  }
}

class _OfflineNotice extends StatelessWidget {
  final bool syncing;
  final VoidCallback onSync;
  const _OfflineNotice({required this.syncing, required this.onSync});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Container(width: 44, height: 44, decoration: BoxDecoration(color: const Color(0xFFE8F5E9), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.cloud_done_rounded, color: Color(0xFF00A86B))),
        const SizedBox(width: 12),
        const Expanded(child: Text('نسخه فعلی بدون اینترنت کار می‌کند. ساختار sync برای پنل آینده آماده است.', style: TextStyle(fontWeight: FontWeight.bold, height: 1.5))),
        TextButton(onPressed: syncing ? null : onSync, child: Text(syncing ? 'بررسی...' : 'بررسی')),
      ]),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18));
}

class _GradeCard extends StatelessWidget {
  final String title;
  final String emoji;
  final Color color;
  final GradeLevel grade;
  final VoidCallback onChanged;
  const _GradeCard({required this.title, required this.emoji, required this.color, required this.grade, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonsListPage(title: title, lessons: OfflineContent.lessons.where((e) => e.grade == grade).toList(), onChanged: onChanged))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(emoji, style: const TextStyle(fontSize: 34)),
        const SizedBox(height: 10),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 5),
        Text('درس‌های ${title.replaceAll('پایه ', '')}', style: const TextStyle(color: Color(0xFF6F665D))),
      ]),
    );
  }
}

class _MenuGrid extends StatelessWidget {
  final VoidCallback onChanged;
  const _MenuGrid({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = [
      _MenuItem('حروف فارسی', 'آ', Icons.abc_rounded, const Color(0xFF7C4DFF), LessonType.letters),
      _MenuItem('اعداد و ریاضی', '۱۲', Icons.calculate_rounded, const Color(0xFFFF7A45), LessonType.numbers),
      _MenuItem('داستان صوتی', '📖', Icons.menu_book_rounded, const Color(0xFF00A86B), LessonType.story),
      _MenuItem('مهارت زندگی', '🧼', Icons.favorite_rounded, const Color(0xFFE91E63), LessonType.lifeSkill),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.03),
      itemBuilder: (_, i) => _MenuCard(item: items[i], onChanged: onChanged),
    );
  }
}

class _MenuItem {
  final String title;
  final String label;
  final IconData icon;
  final Color color;
  final LessonType type;
  const _MenuItem(this.title, this.label, this.icon, this.color, this.type);
}

class _MenuCard extends StatelessWidget {
  final _MenuItem item;
  final VoidCallback onChanged;
  const _MenuCard({required this.item, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final lessons = OfflineContent.lessons.where((e) => e.type == item.type || (item.type == LessonType.numbers && e.type == LessonType.math)).toList();
    return PremiumCard(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonsListPage(title: item.title, lessons: lessons, onChanged: onChanged))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          width: 62,
          height: 62,
          decoration: BoxDecoration(color: item.color.withOpacity(.12), borderRadius: BorderRadius.circular(22)),
          child: Icon(item.icon, color: item.color, size: 34),
        ),
        const SizedBox(height: 12),
        Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16), textAlign: TextAlign.center),
        const SizedBox(height: 4),
        Text('${lessons.length} درس', style: const TextStyle(color: Color(0xFF7A7168), fontSize: 12)),
      ]),
    );
  }
}

class _LearningPath extends StatelessWidget {
  final int completed;
  const _LearningPath({required this.completed});

  @override
  Widget build(BuildContext context) {
    final steps = ['گوش کن', 'با انگشت تمرین کن', 'جواب بده', 'ستاره بگیر'];
    return PremiumCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Expanded(child: Text('مسیر یادگیری', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18))),
          Text('$completed درس کامل شده', style: const TextStyle(color: Color(0xFF00A86B), fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 12),
        for (int i = 0; i < steps.length; i++)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(backgroundColor: const Color(0xFFEAF2FF), child: Text('${i + 1}', style: const TextStyle(color: Color(0xFF2E7DFF), fontWeight: FontWeight.w900))),
            title: Text(steps[i], style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
      ]),
    );
  }
}

class LessonsListPage extends StatefulWidget {
  final String title;
  final List<LessonModel> lessons;
  final VoidCallback onChanged;

  const LessonsListPage({super.key, required this.title, required this.lessons, required this.onChanged});

  @override
  State<LessonsListPage> createState() => _LessonsListPageState();
}

class _LessonsListPageState extends State<LessonsListPage> {
  ProgressModel progress = ProgressModel.empty();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _complete(LessonModel lesson) async {
    progress = await ProgressStore.completeLesson(lesson.id);
    await AppAudio.playAsset('assets/audio/common/correct.mp3');
    widget.onChanged();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return PageShell(
      title: widget.title,
      child: ListView.separated(
        padding: const EdgeInsets.all(18),
        itemCount: widget.lessons.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, i) {
          final lesson = widget.lessons[i];
          final done = progress.completedLessonIds.contains(lesson.id);
          return PremiumCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  width: 64,
                  height: 64,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFEAF2FF), Color(0xFFFFFFFF)]), borderRadius: BorderRadius.circular(22)),
                  child: Text(lesson.display, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: Color(0xFF2E7DFF))),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                  const SizedBox(height: 4),
                  Text(lesson.subtitle, style: const TextStyle(color: Color(0xFF6F665D))),
                ])),
                Icon(done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, color: done ? const Color(0xFF00A86B) : const Color(0xFFB0A79D)),
              ]),
              if (lesson.examples.isNotEmpty) ...[
                const SizedBox(height: 12),
                Wrap(spacing: 8, runSpacing: 8, children: lesson.examples.map((e) => Chip(label: Text(e), backgroundColor: const Color(0xFFFFF8E1), side: BorderSide.none)).toList()),
              ],
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: OutlinedButton.icon(onPressed: lesson.audio == null ? null : () => AppAudio.playAsset(lesson.audio!.localAssetPath), icon: const Icon(Icons.volume_up_rounded), label: const Text('پخش ویس'))),
                const SizedBox(width: 10),
                Expanded(child: ElevatedButton.icon(onPressed: () => _complete(lesson), icon: const Icon(Icons.star_rounded), label: Text(done ? 'تکرار شد' : 'یاد گرفتم'))),
              ]),
            ]),
          );
        },
      ),
    );
  }
}
